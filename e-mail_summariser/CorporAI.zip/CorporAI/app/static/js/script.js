// CorporAI - Email Assistant JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Email processing form on the home page
    const emailForm = document.getElementById('email-form');
    
    if (emailForm) {
        const processResults = document.getElementById('process-results');
        const emailSummary = document.getElementById('email-summary');
        const priorityLevel = document.getElementById('priority-level');
        
        emailForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const emailSubject = document.getElementById('email-subject').value;
            const emailContent = document.getElementById('email-content').value;
            
            // Show loading state
            emailSummary.textContent = 'Processing...';
            priorityLevel.textContent = 'Analyzing...';
            priorityLevel.className = 'result-content priority';
            processResults.style.display = 'block';
            
            // Process the email
            fetch('/process_email', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    'email_subject': emailSubject,
                    'email_content': emailContent
                })
            })
            .then(response => response.json())
            .then(data => {
                emailSummary.textContent = data.summary;
                priorityLevel.textContent = data.priority.toUpperCase();
                priorityLevel.classList.add(`${data.priority}-priority`);
            })
            .catch(error => {
                console.error('Error:', error);
                emailSummary.textContent = 'Error processing email. Please try again.';
                priorityLevel.textContent = 'ERROR';
                priorityLevel.className = 'result-content priority';
            });
        });
    }
    
    // Mailbox Email List Navigation
    const emailList = document.getElementById('email-list');
    if (emailList) {
        const emailItems = emailList.querySelectorAll('.email-item');
        let selectedIndex = -1;
        
        // Function to select an email item
        function selectEmailItem(index) {
            // Remove current selection
            emailItems.forEach(item => item.classList.remove('selected'));
            
            // Apply new selection if valid
            if (index >= 0 && index < emailItems.length) {
                selectedIndex = index;
                emailItems[selectedIndex].classList.add('selected');
                emailItems[selectedIndex].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        }
        
        // Select first email on page load
        if (emailItems.length > 0) {
            selectEmailItem(0);
        }
        
        // Keyboard navigation for email list
        emailList.addEventListener('keydown', function(e) {
            switch(e.key) {
                case 'ArrowDown':
                    e.preventDefault();
                    selectEmailItem(selectedIndex + 1);
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    selectEmailItem(selectedIndex - 1);
                    break;
                case 'Enter':
                    e.preventDefault();
                    if (selectedIndex >= 0) {
                        // Navigate to the selected email
                        const emailLink = emailItems[selectedIndex].querySelector('.email-subject');
                        if (emailLink) {
                            const href = emailLink.getAttribute('href');
                            console.log('Enter key pressed, navigating to:', href);
                            // Use the href property directly to navigate
                            window.location.href = href;
                        }
                    }
                    break;
                case 'Backspace':
                    // Go back to home if on mailbox page
                    if (window.location.pathname.includes('/mailbox')) {
                        window.location.href = '/';
                    }
                    break;
            }
        });
        
        // Click to select an email
        emailItems.forEach((item, index) => {
            item.addEventListener('click', function(e) {
                console.log('Email item clicked:', e.target.tagName, e.target.className);
                
                // Only prevent navigation if clicking on the item itself (not the link)
                // Don't prevent default if clicking on the email-subject link
                if (e.target.classList.contains('email-subject') || 
                    e.target.closest('a.email-subject')) {
                    console.log('Email subject link clicked, allowing navigation');
                    return; // Allow default navigation to occur
                }
                
                // Prevent default for clicks on other parts of the email item
                if (e.target === item || e.target.closest('.email-details')) {
                    console.log('Email details clicked, preventing default navigation');
                    e.preventDefault();
                    selectEmailItem(index);
                }
            });
        });
        
        // Focus the email list on page load for keyboard navigation
        emailList.focus();
        
        // Email search functionality
        const emailSearch = document.getElementById('email-search');
        if (emailSearch) {
            emailSearch.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                let visibleCount = 0;
                
                emailItems.forEach(item => {
                    const subject = item.querySelector('.email-subject').textContent.toLowerCase();
                    const sender = item.querySelector('.email-sender').textContent.toLowerCase();
                    const preview = item.querySelector('.email-preview').textContent.toLowerCase();
                    
                    if (subject.includes(searchTerm) || sender.includes(searchTerm) || preview.includes(searchTerm)) {
                        item.style.display = '';
                        visibleCount++;
                    } else {
                        item.style.display = 'none';
                    }
                });
                
                // Reset selection if all were filtered out
                if (visibleCount > 0 && (selectedIndex === -1 || emailItems[selectedIndex].style.display === 'none')) {
                    // Select the first visible item
                    for (let i = 0; i < emailItems.length; i++) {
                        if (emailItems[i].style.display !== 'none') {
                            selectEmailItem(i);
                            break;
                        }
                    }
                }
            });
        }
        
        // Email sort functionality
        const emailSort = document.getElementById('email-sort');
        if (emailSort) {
            emailSort.addEventListener('change', function() {
                const sortOption = this.value;
                const emailArray = Array.from(emailItems);
                
                emailArray.sort((a, b) => {
                    if (sortOption === 'date_desc' || sortOption === 'date_asc') {
                        const dateA = new Date(a.querySelector('.email-date').textContent);
                        const dateB = new Date(b.querySelector('.email-date').textContent);
                        return sortOption === 'date_desc' ? dateB - dateA : dateA - dateB;
                    } else if (sortOption === 'priority') {
                        const isPriorityA = a.classList.contains('urgent') ? 1 : 0;
                        const isPriorityB = b.classList.contains('urgent') ? 1 : 0;
                        return isPriorityB - isPriorityA;
                    }
                    return 0;
                });
                
                // Reorder elements
                emailArray.forEach(item => {
                    emailList.appendChild(item);
                });
                
                // Reset selection to first email
                if (emailItems.length > 0) {
                    selectEmailItem(0);
                }
            });
        }
    }
    
    // Email View Navigation
    const container = document.querySelector('.container[data-current-email-id]');
    if (container) {
        console.log('Email view page detected');
        const prevEmailBtn = document.getElementById('prev-email');
        const nextEmailBtn = document.getElementById('next-email');
        
        // Keyboard navigation for email view
        document.addEventListener('keydown', function(e) {
            console.log('Key pressed in email view:', e.key);
            switch(e.key) {
                case 'ArrowLeft':
                    e.preventDefault();
                    if (prevEmailBtn && !prevEmailBtn.classList.contains('disabled')) {
                        const href = prevEmailBtn.getAttribute('href');
                        console.log('Navigating to previous email:', href);
                        window.location.href = href;
                    }
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    if (nextEmailBtn && !nextEmailBtn.classList.contains('disabled')) {
                        const href = nextEmailBtn.getAttribute('href');
                        console.log('Navigating to next email:', href);
                        window.location.href = href;
                    }
                    break;
                case 'Backspace':
                    e.preventDefault();
                    // Go back to mailbox
                    console.log('Returning to mailbox from email view');
                    window.location.href = '/mailbox';
                    break;
            }
        });
    }
}); 