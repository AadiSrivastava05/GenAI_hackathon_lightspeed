from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import os
from dotenv import load_dotenv

# Load environment variables first, before importing any modules
load_dotenv(override=True)

from app.models.email_processor import EmailProcessor
from app.models.email_prioritizer import EmailPrioritizer
from app.models.email_summarizer import EmailSummarizer
from app.models.email_store import EmailStore

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Initialize our models and store
email_processor = EmailProcessor()
email_prioritizer = EmailPrioritizer()
email_summarizer = EmailSummarizer()
email_store = EmailStore()

@app.route('/')
def index():
    """Homepage route."""
    return render_template('index.html')

@app.route('/mailbox')
def mailbox():
    """View all emails in the mailbox."""
    # Refresh emails when viewing the mailbox
    emails = email_store.get_all_emails(refresh=True)
    return render_template('mailbox.html', emails=emails)

@app.route('/email/<email_id>')
def view_email(email_id):
    """View a specific email."""
    # Get all emails without refreshing to maintain consistent IDs
    all_emails = email_store.get_all_emails(refresh=False)
    email = None
    prev_email_id = None
    next_email_id = None
    
    # Find the current email and determine prev/next IDs
    for i, e in enumerate(all_emails):
        if e['id'] == email_id:
            email = e
            if i > 0:
                prev_email_id = all_emails[i-1]['id']
            if i < len(all_emails) - 1:
                next_email_id = all_emails[i+1]['id']
            break
    
    if not email:
        return redirect(url_for('mailbox'))
    
    # Generate summary if not already present
    if 'summary' not in email:
        email['summary'] = email_processor.summarize(email['content'])
        email['is_markdown'] = True
    
    return render_template('email.html', email=email, prev_email_id=prev_email_id, next_email_id=next_email_id)

@app.route('/process_email', methods=['POST'])
def process_email():
    """Process an email via API endpoint."""
    email_content = request.form.get('email_content')
    email_subject = request.form.get('email_subject')
    
    # Process the email
    summary = email_processor.summarize(email_content)
    priority = email_prioritizer.classify(email_subject, email_content)
    
    # Create an email object (this would normally be from an email API)
    email = {
        "subject": email_subject,
        "content": email_content,
        "summary": summary,
        "is_markdown": True,
        "is_urgent": priority == "high"
    }
    
    # Store high priority emails
    if priority == "high":
        email_store.add_high_priority_email(email)
    
    return jsonify({
        'summary': summary,
        'priority': priority,
        'is_markdown': True
    })

@app.route('/high_priority')
def high_priority():
    """View all high priority emails."""
    # Get high priority emails, no need to refresh as they'll update when mailbox is visited
    emails = email_store.get_high_priority_emails()
    return render_template('high_priority.html', emails=emails)

@app.route('/high_priority_summary', methods=['GET'])
def high_priority_summary():
    """Generate a summary of all high priority emails."""
    high_priority_emails = email_store.get_high_priority_emails()
    
    if not high_priority_emails:
        return jsonify({'summary': "No high priority emails found.", 'is_markdown': True})
    
    # Generate a meta-summary of all high priority emails
    meta_summary = email_summarizer.meta_summarize(high_priority_emails)
    
    return jsonify({
        'summary': meta_summary,
        'is_markdown': True
    })

if __name__ == '__main__':
    app.run(debug=True) 