import os
import uuid
import datetime
import random
import json
import google.generativeai as genai
from typing import List, Dict, Any
import pickle
from dotenv import load_dotenv
import time

class GeminiEmailGenerator:
    """Generate realistic corporate emails using Gemini API"""
    
    def __init__(self, requests_per_minute=10):
        # Load environment variables to ensure API key is available
        load_dotenv()
        
        # Get API key from environment variable
        api_key = os.environ.get('GEMINI_API_KEY')
        if not api_key or api_key == 'your-api-key-here':
            raise ValueError("Valid Gemini API key is required. Please check your .env file.")
            
        # Initialize the Gemini API
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-2.0-flash')
        
        # Rate limiting settings
        self.requests_per_minute = requests_per_minute
        self.request_interval = 60.0 / requests_per_minute
        self.last_request_time = 0
        
        # Define sender profiles (same as in mock_emails.py)
        self.senders = [
            # Executives
            {"name": "John Smith", "email": "john.smith@corporation.com", "title": "CEO"},
            {"name": "Sarah Johnson", "email": "sarah.j@corporation.com", "title": "CFO"},
            {"name": "Michael Chen", "email": "m.chen@corporation.com", "title": "CTO"},
            {"name": "Emily Davis", "email": "e.davis@corporation.com", "title": "COO"},
            # Managers
            {"name": "James Wilson", "email": "j.wilson@corporation.com", "title": "Project Manager"},
            {"name": "Lisa Brown", "email": "l.brown@corporation.com", "title": "HR Manager"},
            {"name": "David Garcia", "email": "d.garcia@corporation.com", "title": "Marketing Manager"},
            {"name": "Karen Lee", "email": "k.lee@corporation.com", "title": "Sales Manager"},
            # Team members
            {"name": "Alex Turner", "email": "a.turner@corporation.com", "title": "Software Engineer"},
            {"name": "Sofia Rodriguez", "email": "s.rodriguez@corporation.com", "title": "UX Designer"},
            {"name": "Robert Kim", "email": "r.kim@corporation.com", "title": "Data Analyst"},
            {"name": "Jennifer Wong", "email": "j.wong@corporation.com", "title": "Content Writer"},
            # External
            {"name": "Thomas Clark", "email": "thomas@client.com", "title": "Client"},
            {"name": "Rachel Green", "email": "rachel@partner.com", "title": "Partner"},
            {"name": "Newsletter", "email": "news@industry.com", "title": "Industry Newsletter"}
        ]
        
        self.projects = ["Phoenix", "Evergreen", "Atlas", "Horizon", "Quantum", "Nexus", "Titan"]
        
        self.email_types = [
            {"type": "meeting", "weight": 25},
            {"type": "update", "weight": 20},
            {"type": "request", "weight": 15},
            {"type": "urgent", "weight": 10},
            {"type": "fyi", "weight": 20},
            {"type": "newsletter", "weight": 10}
        ]
        
        # Cache file path for storing generated emails
        self.cache_file = os.path.join(os.path.dirname(__file__), 'generated_emails.pkl')
    
    def _apply_rate_limit(self):
        """Apply rate limiting to avoid hitting API limits."""
        current_time = time.time()
        time_since_last_request = current_time - self.last_request_time
        
        if time_since_last_request < self.request_interval:
            sleep_time = self.request_interval - time_since_last_request
            print(f"Rate limit: Waiting {sleep_time:.2f} seconds before next request...")
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def _random_date(self, days_back: int = 30) -> datetime.datetime:
        """Generate a random date within the past specified days."""
        current_date = datetime.datetime.now()
        random_days = random.randint(0, days_back)
        random_hours = random.randint(0, 23)
        random_minutes = random.randint(0, 59)
        return current_date - datetime.timedelta(days=random_days, hours=random_hours, minutes=random_minutes)
    
    def _generate_email_prompt(self, email_type: str, sender: Dict[str, str]) -> str:
        """Generate a prompt for Gemini to create a realistic corporate email."""
        project = random.choice(self.projects) if random.random() > 0.3 else None
        is_urgent = True if email_type == "urgent" else (random.random() < 0.2)
        
        prompt = f"""Generate a realistic corporate email with the following characteristics:
- Email type: {email_type}
- Sender name: {sender['name']}
- Sender title: {sender['title']}
- Sender email: {sender['email']}
{"- Related to project: " + project if project else ""}
{"- This is an URGENT email" if is_urgent else ""}

The email should have:
1. A realistic subject line {"with [URGENT] prefix" if is_urgent else ""}
2. Detailed professional corporate email content
3. Proper email formatting with greetings and signature

Respond with a JSON object containing these fields:
{{
  "subject": "The subject line",
  "content": "The full email content with proper formatting"
}}
"""
        return prompt
    
    def _generate_email_with_gemini(self, email_type: str, sender: Dict[str, str]) -> Dict[str, Any]:
        """Generate an email using Gemini API."""
        prompt = self._generate_email_prompt(email_type, sender)
        
        try:
            # Apply rate limiting before making API request
            self._apply_rate_limit()
            
            # Make the API request
            response = self.model.generate_content(prompt)
            result = response.text
            
            # Extract JSON from the response
            try:
                # Try to parse as JSON directly
                email_data = json.loads(result)
            except json.JSONDecodeError:
                # If direct parsing fails, try to extract JSON from markdown code block
                if "```json" in result and "```" in result.split("```json", 1)[1]:
                    json_content = result.split("```json", 1)[1].split("```", 1)[0].strip()
                    email_data = json.loads(json_content)
                else:
                    # Fallback if JSON extraction fails
                    email_data = {
                        "subject": f"Failed to generate subject for {email_type} email",
                        "content": f"Failed to generate content for {email_type} email"
                    }
            
            # Determine if the email is urgent based on subject
            is_urgent = "[URGENT]" in email_data["subject"] or email_type == "urgent"
            
            return {
                "id": str(uuid.uuid4()),
                "sender": sender,
                "subject": email_data["subject"],
                "content": email_data["content"],
                "date": self._random_date(),
                "category": email_type,
                "is_urgent": is_urgent
            }
        
        except Exception as e:
            print(f"Error generating email: {str(e)}")
            # Fallback to basic email on error
            return {
                "id": str(uuid.uuid4()),
                "sender": sender,
                "subject": f"[{email_type.upper()}] {random.choice(self.projects) if random.random() > 0.3 else 'General'} Update",
                "content": f"This is a placeholder email due to an error in generation.\n\nBest regards,\n{sender['name']}\n{sender['title']}",
                "date": self._random_date(),
                "category": email_type,
                "is_urgent": email_type == "urgent"
            }
    
    def generate_emails(self, count: int = 200, batch_size: int = 5) -> List[Dict[str, Any]]:
        """Generate the specified number of emails using Gemini API."""
        # Check if emails are already cached
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'rb') as f:
                    cached_emails = pickle.load(f)
                    if len(cached_emails) >= count:
                        print(f"Loaded {count} emails from cache.")
                        return cached_emails[:count]
            except Exception as e:
                print(f"Error loading cached emails: {str(e)}")
        
        emails = []
        print(f"Generating {count} emails using Gemini API. This may take a while...")
        print(f"API Key status: Using key ending with ...{os.environ.get('GEMINI_API_KEY', '')[-4:] if os.environ.get('GEMINI_API_KEY') else 'Not set'}")
        print(f"Rate limiting: Maximum {self.requests_per_minute} requests per minute")
        
        # Calculate how many emails of each type to generate based on weights
        total_weight = sum(email_type["weight"] for email_type in self.email_types)
        type_counts = {}
        remaining = count
        
        for email_type in self.email_types:
            if email_type == self.email_types[-1]:
                # Last type gets all remaining emails
                type_counts[email_type["type"]] = remaining
            else:
                # Calculate proportional count
                type_count = int((email_type["weight"] / total_weight) * count)
                type_counts[email_type["type"]] = type_count
                remaining -= type_count
        
        print(f"Email distribution by type: {type_counts}")
        
        # Try a test call to Gemini API before generating all emails
        try:
            print("Testing Gemini API connection...")
            self._apply_rate_limit()
            test_prompt = "Generate a simple test email subject."
            response = self.model.generate_content(test_prompt)
            print(f"API test successful: {response.text[:40]}...")
        except Exception as e:
            print(f"ERROR: Failed to connect to Gemini API: {str(e)}")
            raise ValueError(f"Cannot generate emails: {str(e)}")
        
        # Generate emails in batches with intermediate saving
        emails_to_generate = []
        for email_type, type_count in type_counts.items():
            for _ in range(type_count):
                sender = random.choice(self.senders)
                emails_to_generate.append((email_type, sender))
        
        # Process in smaller batches to prevent losing progress if interrupted
        batch_count = (len(emails_to_generate) + batch_size - 1) // batch_size
        for batch_idx in range(batch_count):
            batch_start = batch_idx * batch_size
            batch_end = min(batch_start + batch_size, len(emails_to_generate))
            batch = emails_to_generate[batch_start:batch_end]
            
            print(f"\nProcessing batch {batch_idx + 1}/{batch_count} (emails {batch_start + 1}-{batch_end})...")
            
            # Generate emails in this batch
            for i, (email_type, sender) in enumerate(batch):
                try:
                    email = self._generate_email_with_gemini(email_type, sender)
                    emails.append(email)
                    
                    # Print progress
                    print(f"Generated {len(emails)}/{count} emails...")
                    
                    # Save intermediate results after each batch item
                    if i % 2 == 1:
                        try:
                            with open(self.cache_file, 'wb') as f:
                                pickle.dump(emails, f)
                            print(f"Saved intermediate progress ({len(emails)} emails) to cache.")
                        except Exception as e:
                            print(f"Warning: Failed to save intermediate progress: {str(e)}")
                
                except Exception as e:
                    print(f"Error generating {email_type} email from {sender['name']}: {str(e)}")
                    # Create a fallback email but continue
                    emails.append({
                        "id": str(uuid.uuid4()),
                        "sender": sender,
                        "subject": f"[{email_type.upper()}] {random.choice(self.projects)} Update",
                        "content": f"This is a placeholder email due to generation error: {str(e)}\n\nBest regards,\n{sender['name']}\n{sender['title']}",
                        "date": self._random_date(),
                        "category": email_type,
                        "is_urgent": email_type == "urgent"
                    })
            
            # Save progress after each batch
            try:
                with open(self.cache_file, 'wb') as f:
                    pickle.dump(emails, f)
                print(f"Saved batch {batch_idx + 1} progress to cache. Total emails: {len(emails)}")
            except Exception as e:
                print(f"Error saving emails to cache: {str(e)}")
        
        # Final save of all emails
        if emails:
            try:
                with open(self.cache_file, 'wb') as f:
                    pickle.dump(emails, f)
                print(f"Saved all {len(emails)} emails to cache.")
            except Exception as e:
                print(f"Error saving emails to cache: {str(e)}")
        else:
            print("WARNING: No emails were generated successfully.")
        
        return emails

def generate_and_save_emails(count: int = 200):
    """Generate emails and save them to a cache file."""
    generator = GeminiEmailGenerator(requests_per_minute=6)  # Conservative rate limit
    emails = generator.generate_emails(count, batch_size=10)
    return emails 