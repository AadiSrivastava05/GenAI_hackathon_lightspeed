import google.generativeai as genai
import os
from dotenv import load_dotenv

# Ensure environment variables are loaded
load_dotenv(override=True)

class EmailProcessor:
    def __init__(self):
        # Initialize the Gemini API
        genai.configure(api_key=os.environ.get('GEMINI_API_KEY', 'your-api-key-here'))
        self.model = genai.GenerativeModel('gemini-2.0-flash')
    
    def summarize(self, email_content):
        """
        Use Gemini to summarize the email content, keeping any important keywords.
        
        Args:
            email_content (str): The content of the email to summarize
            
        Returns:
            str: A concise summary of the email in markdown format
        """
        prompt = f"""
        Summarize the following email in a concise manner. Highlight any important keywords, 
        dates, action items, or critical information. Format your response using Markdown with:
        
        - Headings (## for main sections, ### for subsections)
        - **Bold** for important terms, deadlines, or action items
        - Bullet points for lists of information
        - > Blockquotes for any direct quotes that are important
        
        Keep your summary structured and well-formatted with proper markdown.
        
        EMAIL:
        {email_content}
        """
        
        try:
            response = self.model.generate_content(prompt)
            return response.text
        except Exception as e:
            print(f"Error summarizing email: {e}")
            return "Failed to summarize email." 