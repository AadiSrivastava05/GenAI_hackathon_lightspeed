import random
import datetime
import uuid
from typing import List, Dict, Any

class MockEmailGenerator:
    """Generate mock corporate emails for testing purposes."""
    
    def __init__(self):
        self.senders = [
            # Executives
            {"name": "John Smith", "email": "john.smith@corporation.com", "title": "CEO"},
            {"name": "Sarah Johnson", "email": "sarah.j@corporation.com", "title": "CFO"},
            {"name": "Michael Chen", "email": "m.chen@corporation.com", "title": "CTO"},
            {"name": "Emily Davis", "email": "e.davis@corporation.com", "title": "COO"},
            # Managers
            {"name": "James Wilson", "email": "j.wilson@corporation.com", "title": "Project Manager"},
            {"name": "Lisa Brown", "email": "l.brown@corporation.com", "title": "HR Manager"},
            {"name": "David Garcia", "email": "d.garcia@corporation.com", "title": "Marketing Manager"},
            {"name": "Karen Lee", "email": "k.lee@corporation.com", "title": "Sales Manager"},
            # Team members
            {"name": "Alex Turner", "email": "a.turner@corporation.com", "title": "Software Engineer"},
            {"name": "Sofia Rodriguez", "email": "s.rodriguez@corporation.com", "title": "UX Designer"},
            {"name": "Robert Kim", "email": "r.kim@corporation.com", "title": "Data Analyst"},
            {"name": "Jennifer Wong", "email": "j.wong@corporation.com", "title": "Content Writer"},
            # External
            {"name": "Thomas Clark", "email": "thomas@client.com", "title": "Client"},
            {"name": "Rachel Green", "email": "rachel@partner.com", "title": "Partner"},
            {"name": "Newsletter", "email": "news@industry.com", "title": "Industry Newsletter"}
        ]
        
        self.projects = ["Phoenix", "Evergreen", "Atlas", "Horizon", "Quantum", "Nexus", "Titan"]
        
        self.email_types = [
            {"type": "meeting", "weight": 25},
            {"type": "update", "weight": 20},
            {"type": "request", "weight": 15},
            {"type": "urgent", "weight": 10},
            {"type": "fyi", "weight": 20},
            {"type": "newsletter", "weight": 10}
        ]
        
        # Generate current date and random past dates
        self.current_date = datetime.datetime.now()
    
    def _random_date(self, days_back: int = 30) -> datetime.datetime:
        """Generate a random date within the past specified days."""
        random_days = random.randint(0, days_back)
        random_hours = random.randint(0, 23)
        random_minutes = random.randint(0, 59)
        return self.current_date - datetime.timedelta(days=random_days, hours=random_hours, minutes=random_minutes)
    
    def _generate_meeting_email(self, sender: Dict[str, str]) -> Dict[str, Any]:
        """Generate a meeting invitation email."""
        meeting_types = ["Team Meeting", "Project Update", "Planning Session", "Review", "One-on-one", "All Hands"]
        meeting_type = random.choice(meeting_types)
        project = random.choice(self.projects) if random.random() > 0.3 else ""
        
        # Generate a meeting date and time (in the future)
        meeting_days_ahead = random.randint(1, 14)
        meeting_hour = random.randint(9, 17)
        meeting_date = (self.current_date + datetime.timedelta(days=meeting_days_ahead)).replace(
            hour=meeting_hour, minute=random.choice([0, 15, 30, 45]), second=0, microsecond=0
        )
        
        # Format meeting date
        meeting_date_str = meeting_date.strftime("%A, %B %d at %I:%M %p")
        meeting_end_time = (meeting_date + datetime.timedelta(minutes=random.choice([30, 45, 60, 90]))).strftime("%I:%M %p")
        
        is_urgent = random.random() < 0.2
        
        subject = f"{'[URGENT] ' if is_urgent else ''}Meeting: {meeting_type}{' - Project ' + project if project else ''}"
        
        # Generate meeting location
        locations = ["Conference Room A", "Conference Room B", "Virtual Zoom Meeting", "Microsoft Teams", "Main Office", "Client Site", "Headquarters Floor 3"]
        meeting_location = random.choice(locations)
        
        # Generate meeting participants
        participant_count = random.randint(3, 8)
        participants = []
        for _ in range(participant_count):
            participants.append(random.choice(self.senders)["name"])
        
        # Background information for the meeting
        background_options = [
            f"This is a follow-up to our discussion last week regarding {random.choice(['the project timeline', 'resource allocation', 'client feedback', 'the technical implementation'])}.",
            f"As discussed in our last meeting, we need to address {random.choice(['the upcoming deadline', 'recent feedback from stakeholders', 'technical challenges', 'budget constraints'])}.",
            f"This meeting is part of our {random.choice(['weekly sync', 'monthly review', 'quarterly planning', 'project kickoff'])} process.",
            f"Based on recent developments with {random.choice(['the client', 'the market', 'our competitors', 'regulatory requirements'])}, we need to realign our strategy."
        ]
        background = random.choice(background_options)
        
        # Required preparation
        preparation_options = [
            f"Please review the {random.choice(['attached documents', 'latest metrics', 'project timeline', 'technical specifications'])} before the meeting.",
            f"Come prepared with your {random.choice(['status updates', 'questions', 'feedback on the proposal', 'ideas for improvement'])}.",
            f"If you have any specific topics to add to the agenda, please reply to this email by {(self.current_date + datetime.timedelta(days=random.randint(1, 3))).strftime('%A')}.",
            f"Please complete the pre-meeting survey that was sent separately."
        ]
        preparation = random.choice(preparation_options)
        
        content = f"""Dear Team,

I'd like to schedule a {meeting_type.lower()}{' for Project ' + project if project else ''} on {meeting_date_str} until {meeting_end_time}.

Location: {meeting_location}

Background:
{background}

Agenda:
1. {random.choice(['Welcome and introduction', 'Status updates', 'Progress review', 'Discussion of recent developments'])} (10 min)
2. {random.choice(['Planning for next steps', 'Address blockers', 'Resource allocation', 'Timeline review'])} (15 min)
3. {random.choice(['Technical discussion', 'Budget review', 'Client feedback', 'Market analysis'])} (20 min)
4. {random.choice(['Q&A', 'Action items', 'Timeline adjustments', 'Risk assessment'])} (10 min)
5. {random.choice(['Wrap-up and next steps', 'Task assignments', 'Follow-up schedule', 'Summary'])} (5 min)

Key topics to be covered:
- {random.choice(['Current project status and milestones', 'Technical challenges and solutions', 'Resource requirements', 'Client expectations'])}
- {random.choice(['Budget allocation and constraints', 'Timeline adjustments', 'Team responsibilities', 'Quality assurance measures'])}
- {random.choice(['Market feedback and competitive analysis', 'Performance metrics', 'Strategic goals', 'Innovation opportunities'])}
- {random.choice(['Upcoming deadlines and deliverables', 'Cross-team dependencies', 'Risk mitigation strategies', 'Success criteria'])}

Participants:
{', '.join(participants)}

Preparation:
{preparation}

Additional Information:
{random.choice([
    f"This meeting is {random.choice(['critical for', 'important to', 'essential to', 'necessary for'])} ensuring we stay on track with our objectives.",
    f"We've allocated extra time for this meeting to ensure we can address all concerns thoroughly.",
    f"Please prioritize attending this meeting as decisions made will impact {random.choice(['the entire project', 'our quarterly goals', 'team workflows', 'client deliverables'])}.",
    f"If you cannot attend, please delegate to someone who can represent your perspective and make decisions."
])}

{random.choice(['Please come prepared with your updates.', 'Looking forward to our discussion.', 'I value your input on these matters.', 'Your active participation is appreciated.'])}

{random.choice(['Best regards', 'Thanks', 'Regards', 'Best', 'With appreciation'])}
{sender['name']}
{sender['title']}
"""
        
        return {
            "id": str(uuid.uuid4()),
            "sender": sender,
            "subject": subject,
            "content": content,
            "date": self._random_date(),
            "category": "meeting",
            "is_urgent": is_urgent
        }
    
    def _generate_update_email(self, sender: Dict[str, str]) -> Dict[str, Any]:
        """Generate a project update email."""
        project = random.choice(self.projects)
        progress = random.randint(10, 100)
        is_urgent = random.random() < 0.1
        
        subject = f"{'[URGENT] ' if is_urgent else ''}Project {project} - {random.choice(['Weekly Update', 'Progress Report', 'Status Update'])}"
        
        # Generate milestone or delay message
        milestone_or_delay = ""
        if random.random() < 0.3:
            if random.random() < 0.5:
                milestone = random.choice([
                    'completed backend integration', 
                    'finished UI design', 
                    'deployed to staging', 
                    'completed user testing',
                    'finalized API documentation',
                    'implemented security protocols',
                    'achieved performance targets',
                    'completed third-party integrations'
                ])
                
                milestone_details = random.choice([
                    f"This puts us ahead of schedule by approximately {random.randint(1, 5)} days.",
                    f"The team worked exceptionally well to complete this ahead of the projected timeline.",
                    f"Despite some challenges, we managed to deliver this important component on time.",
                    f"This represents a significant achievement for the project and demonstrates our team's capabilities."
                ])
                
                milestone_or_delay = f"We've reached an important milestone: {milestone}. {milestone_details}\n\n"
            else:
                delay_issue = random.choice([
                    'delays', 
                    'challenges', 
                    'issues', 
                    'setbacks',
                    'impediments',
                    'complications',
                    'obstacles'
                ])
                
                delay_area = random.choice([
                    'the backend', 
                    'the frontend', 
                    'integration', 
                    'resource allocation',
                    'third-party dependencies',
                    'server infrastructure',
                    'quality assurance',
                    'performance optimization',
                    'security implementation'
                ])
                
                delay_action = random.choice([
                    'Working on a solution.', 
                    'Need assistance to resolve this.', 
                    'Adjusting timeline accordingly.',
                    'Have identified potential workarounds.',
                    'Consulting with experts to address this.',
                    'Reallocating resources to mitigate impact.',
                    'Developing a contingency plan.',
                    'May need to adjust project scope.'
                ])
                
                delay_impact = random.choice([
                    f"This may delay our projected completion date by approximately {random.randint(1, 10)} days.",
                    f"Impact to the overall timeline is being assessed, preliminary estimate is {random.randint(3, 7)} days.",
                    f"We are confident we can absorb this delay within the existing timeline by reallocating resources.",
                    f"This could affect dependent workstreams including {random.choice(['UI development', 'backend services', 'testing phase', 'client delivery'])}."
                ])
                
                milestone_or_delay = f"We're experiencing some {delay_issue} with {delay_area}. {delay_action} {delay_impact}\n\n"
        
        # Generate team updates
        team_members = random.sample(self.senders, k=random.randint(2, 4))
        team_updates = []
        for member in team_members:
            update = random.choice([
                f"{member['name']} has {random.choice(['joined the team', 'completed their assigned tasks', 'made significant progress on', 'identified a solution for'])} {random.choice(['component X', 'the UI redesign', 'performance bottlenecks', 'integration issues'])}.",
                f"{member['name']} will be {random.choice(['focusing on', 'responsible for', 'taking the lead on', 'providing expertise for'])} {random.choice(['the next phase', 'user acceptance testing', 'security audits', 'client presentations'])}.",
                f"{member['name']} has {random.choice(['identified', 'resolved', 'documented', 'analyzed'])} {random.choice(['several critical bugs', 'performance issues', 'potential enhancements', 'security vulnerabilities'])}."
            ])
            team_updates.append(update)
        
        # Generate resource updates
        resource_update = random.choice([
            f"We've {random.choice(['allocated', 'secured', 'requested', 'reassigned'])} additional {random.choice(['developers', 'designers', 'testers', 'infrastructure', 'budget'])} for the next phase.",
            f"Current resource utilization is at {random.randint(70, 95)}%, which is {random.choice(['as expected', 'slightly higher than anticipated', 'within acceptable limits', 'being closely monitored'])}.",
            f"We may need to {random.choice(['request additional resources', 'reassess resource allocation', 'engage specialized expertise', 'adjust our resource plan'])} based on recent developments.",
            f"Resource forecasting for Q{random.randint(1, 4)} shows {random.choice(['adequate capacity', 'potential constraints', 'need for additional headcount', 'budget requirements'])}."
        ])
        
        # Generate risk assessment
        risks = [
            f"Potential {random.choice(['delay in third-party integration', 'resource constraints during holiday season', 'technical complexity exceeding estimates', 'scope creep'])}.",
            f"Concern about {random.choice(['meeting performance requirements', 'security compliance standards', 'compatibility with legacy systems', 'user adoption'])}.",
            f"Dependency on {random.choice(['external vendor delivery', 'client approval processes', 'infrastructure upgrades', 'regulatory approvals'])}."
        ]
        
        risk_selected = random.sample(risks, k=random.randint(1, 3))
        risk_mitigation = random.choice([
            "We've implemented mitigation strategies for each identified risk.",
            "Our risk management plan has been updated accordingly.",
            "We're closely monitoring these risks with contingency plans in place.",
            "Weekly risk assessments are being conducted to stay ahead of potential issues."
        ])
        
        # Generate client/stakeholder feedback
        client_feedback = ""
        if random.random() < 0.4:
            client_feedback = f"""Client/Stakeholder Feedback:
{random.choice([
    f"Client is {random.choice(['satisfied with progress', 'concerned about timeline', 'requesting additional features', 'impressed with recent demos'])}.",
    f"Stakeholders have {random.choice(['expressed confidence in the team', 'requested more frequent updates', 'emphasized the importance of on-time delivery', 'suggested some design changes'])}.",
    f"Recent demo received {random.choice(['positive feedback', 'constructive criticism', 'valuable suggestions', 'approval to proceed'])}.",
    f"Executive sponsor {random.choice(['wants to showcase the project at upcoming event', 'has highlighted our work to the board', 'is closely monitoring our progress', 'has requested a detailed review'])}."])}

"""
        
        content = f"""Hello Team,

Here's the latest update on Project {project}:

Current Progress: {progress}%

{milestone_or_delay}Key achievements this {random.choice(['week', 'sprint', 'period', 'phase'])}:
- {random.choice(['Completed feature X', 'Fixed critical bugs', 'Implemented new design', 'Optimized database queries', 'Deployed to staging environment', 'Integrated with external API', 'Finalized documentation'])}
- {random.choice(['Onboarded new team member', 'Updated documentation', 'Refactored code module', 'Added test coverage', 'Improved CI/CD pipeline', 'Enhanced security measures', 'Optimized performance'])}
- {random.choice(['Conducted code reviews', 'Completed peer testing', 'Updated project plan', 'Resolved major blockers', 'Simplified architecture', 'Improved user experience', 'Automated repetitive tasks'])}
- {random.choice(['Aligned with stakeholders', 'Updated requirements documentation', 'Refined acceptance criteria', 'Clarified technical specifications', 'Resolved ambiguities in requirements'])}

Next steps:
- {random.choice(['Complete feature Y', 'Start integration testing', 'Review pending PRs', 'Prepare for release', 'Begin user acceptance testing', 'Finalize deployment plan', 'Conduct performance testing'])}
- {random.choice(['Meet with stakeholders', 'Update project timeline', 'Address technical debt', 'Schedule demo', 'Prepare client presentation', 'Review security considerations', 'Optimize for scale'])}
- {random.choice(['Begin work on next phase', 'Document lessons learned', 'Plan resource allocation', 'Coordinate with other teams', 'Update technical documentation', 'Review quality metrics'])}

Team Updates:
{team_updates[0]}
{team_updates[1] if len(team_updates) > 1 else ""}

Resource Update:
{resource_update}

Risk Assessment:
{chr(10).join("- " + risk for risk in risk_selected)}
{risk_mitigation}

{client_feedback}Timeline:
- Current phase estimated completion: {(self.current_date + datetime.timedelta(days=random.randint(5, 30))).strftime("%B %d, %Y")}
- Overall project timeline: {random.choice(['On track', 'Slightly behind', 'Ahead of schedule', 'Needs reassessment'])}

Metrics:
- Bugs resolved: {random.randint(5, 20)}
- Test coverage: {random.randint(70, 95)}%
- Performance: {random.choice(['Meeting targets', 'Exceeding expectations', 'Needs optimization', 'Within acceptable range'])}

{random.choice(['Please let me know if you have any questions.', 'Looking forward to your feedback.', 'Let me know if anything needs clarification.', 'Feel free to reach out if you need more details on any aspect.'])}

{random.choice(['Best regards', 'Thanks', 'Regards', 'Best', 'With appreciation'])}
{sender['name']}
{sender['title']}
"""
        
        return {
            "id": str(uuid.uuid4()),
            "sender": sender,
            "subject": subject,
            "content": content,
            "date": self._random_date(),
            "category": "update",
            "is_urgent": is_urgent
        }
    
    def _generate_request_email(self, sender: Dict[str, str]) -> Dict[str, Any]:
        """Generate a request email."""
        request_types = [
            "document review", "budget approval", "resource allocation", 
            "design feedback", "code review", "help with a task",
            "project proposal evaluation", "technical consultation",
            "feature prioritization", "strategic input"
        ]
        request_type = random.choice(request_types)
        is_urgent = random.random() < 0.3
        deadline = None
        
        if random.random() < 0.7:
            days_ahead = random.randint(1, 10)
            deadline = (self.current_date + datetime.timedelta(days=days_ahead)).strftime("%A, %B %d")
        
        # Generate context information
        context_options = [
            f"As part of our work on Project {random.choice(self.projects)}, we need to finalize this aspect before proceeding.",
            f"Following our recent discussion about {random.choice(['quarterly goals', 'team objectives', 'client requirements', 'product roadmap'])}, this requires your attention.",
            f"Based on {random.choice(['recent feedback', 'market analysis', 'performance metrics', 'client requests'])}, we need to make some adjustments that require your input.",
            f"In preparation for the upcoming {random.choice(['release', 'client meeting', 'board presentation', 'audit'])}, we need your expertise on this matter."
        ]
        
        # Generate specific request details
        request_details_map = {
            "document review": [
                f"The document is {random.randint(10, 50)} pages and focuses on {random.choice(['technical specifications', 'project plan', 'market analysis', 'financial projections'])}.",
                f"Key areas requiring your attention: {random.choice(['Section 3.2 on methodology', 'financial forecasts', 'risk assessment', 'technical implementation details'])}.",
                f"This is version {random.randint(1, 5)}.{random.randint(0, 9)} with changes highlighted for your convenience.",
                f"We especially need your expertise on {random.choice(['compliance aspects', 'technical accuracy', 'strategic alignment', 'resource requirements'])}."
            ],
            "budget approval": [
                f"The requested budget is ${random.randint(10, 100)}k for {random.choice(['Q1', 'Q2', 'Q3', 'Q4'])} activities.",
                f"This represents a {random.choice(['5%', '10%', '15%', 'slight'])} {random.choice(['increase', 'decrease'])} from our previous allocation.",
                f"Primary allocation areas include: {random.choice(['staffing', 'infrastructure', 'marketing', 'R&D'])} ({random.randint(30, 60)}%) and {random.choice(['technology', 'operations', 'customer acquisition', 'product development'])} ({random.randint(20, 40)}%).",
                f"ROI projections and justifications are detailed in the attached spreadsheet."
            ],
            "resource allocation": [
                f"We need {random.randint(1, 5)} {random.choice(['developers', 'designers', 'analysts', 'QA specialists'])} for approximately {random.randint(2, 8)} weeks.",
                f"This is to support {random.choice(['a critical client project', 'our product launch', 'an important infrastructure upgrade', 'a time-sensitive market opportunity'])}.",
                f"Without these resources, we risk {random.choice(['missing our deadline', 'compromising quality', 'losing the client', 'missing market opportunity'])}.",
                f"We've already optimized our current team allocation and explored alternatives."
            ]
        }
        
        # Default request details if not specifically mapped
        default_request_details = [
            f"This requires approximately {random.randint(1, 10)} hours of your time.",
            f"Your specific expertise in {random.choice(['technical architecture', 'user experience', 'market strategy', 'risk assessment'])} would be invaluable.",
            f"The scope is {random.choice(['limited to specific aspects', 'comprehensive but well-defined', 'focused on high-level review', 'detailed but manageable'])}.",
            f"We've prepared all necessary supporting materials to make this process efficient for you."
        ]
        
        # Get appropriate request details or use default
        request_details = request_details_map.get(request_type, default_request_details)
        selected_details = random.sample(request_details, k=random.randint(2, len(request_details)))
        
        # Generate impact statement
        impact_options = [
            f"Your input will directly influence {random.choice(['our approach to the market', 'technical implementation decisions', 'resource investment', 'client satisfaction'])}.",
            f"This will help us {random.choice(['meet critical deadlines', 'maintain quality standards', 'address client concerns', 'optimize our processes'])}.",
            f"The outcome will affect {random.choice(['multiple teams', 'our quarterly results', 'client relationships', 'product roadmap'])}.",
            f"This is a key component of our {random.choice(['strategic initiatives', 'operational excellence program', 'client retention strategy', 'innovation efforts'])}."
        ]
        
        # Generate available times if applicable
        available_times = ""
        if random.random() < 0.4:
            days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
            times = ["9:00 AM - 10:00 AM", "11:00 AM - 12:00 PM", "2:00 PM - 3:00 PM", "4:00 PM - 5:00 PM"]
            available_days = random.sample(days, k=random.randint(2, 3))
            available_time_slots = random.sample(times, k=random.randint(2, 3))
            
            available_times = f"""
Available times to discuss this further:
{chr(10).join("- " + day + ": " + ", ".join(available_time_slots) for day in available_days)}

Please let me know what works for you.
"""
        
        subject = f"{'[URGENT] ' if is_urgent else ''}Request for {request_type.title()}"
        
        content = f"""Hello {random.choice(['', 'Team', random.choice([s['name'].split()[0] for s in self.senders])])},

I'm reaching out to request your {request_type}.

Context:
{random.choice(context_options)}

{random.choice([
    f"I need your input on {random.choice(['the latest designs', 'the project proposal', 'the marketing materials', 'the financial projections', 'technical architecture', 'user experience flows', 'performance optimization strategy'])}.",
    f"Could you please review {random.choice(['the attached document', 'the latest changes', 'my proposal', 'the code changes', 'our strategy document', 'the implementation plan', 'the risk analysis'])}?",
    f"We need {random.choice(['additional resources', 'your expertise', 'approval to proceed', 'your sign-off', 'strategic guidance', 'technical direction', 'budget allocation'])} for the next phase."
])}

Request Details:
{chr(10).join("- " + detail for detail in selected_details)}

Impact:
{random.choice(impact_options)}

{f'The deadline for this is {deadline}.' if deadline else ''}
{f'This is urgent and requires your attention by {(self.current_date + datetime.timedelta(days=random.randint(1, 3))).strftime("%A")}.' if is_urgent else ''}

Next Steps:
{random.choice([
    "Please review the attached materials and provide your feedback.",
    "Let me know if you can accommodate this request and what your timeline might be.",
    "If you approve, we'll proceed with implementation immediately.",
    "Please schedule a meeting with me to discuss this further if you have questions."
])}

{available_times}
{random.choice(['Your input is greatly appreciated.', 'Thanks in advance for your help.', 'Looking forward to your response.', 'Your expertise is invaluable to us.'])}

{random.choice(['Best regards', 'Thanks', 'Regards', 'Best', 'With appreciation'])}
{sender['name']}
{sender['title']}
"""
        
        return {
            "id": str(uuid.uuid4()),
            "sender": sender,
            "subject": subject,
            "content": content,
            "date": self._random_date(),
            "category": "request",
            "is_urgent": is_urgent
        }
    
    def _generate_urgent_email(self, sender: Dict[str, str]) -> Dict[str, Any]:
        """Generate an urgent email."""
        urgent_topics = [
            "System Outage", "Critical Bug", "Client Escalation", 
            "Security Incident", "Deadline Change", "Immediate Action Required",
            "Production Issue", "Emergency Response Needed", "Critical Vulnerability",
            "Urgent Client Request"
        ]
        topic = random.choice(urgent_topics)
        
        subject = f"[URGENT] {topic} - Immediate Attention Required"
        
        # Generate incident details
        incident_details = {
            "System Outage": [
                f"Our {random.choice(['primary database', 'authentication system', 'payment processing system', 'API gateway', 'main application server'])} went down at {(self.current_date - datetime.timedelta(hours=random.randint(1, 5))).strftime('%H:%M')}.",
                f"Affected systems: {', '.join(random.sample(['User authentication', 'Payment processing', 'Order management', 'Customer data', 'Backend services', 'External API connections'], k=random.randint(2, 4)))}",
                f"Current status: {random.choice(['Complete outage', 'Intermittent availability', 'Degraded performance', 'Read-only mode'])}",
                f"Initial diagnosis points to {random.choice(['database corruption', 'network failure', 'resource exhaustion', 'configuration error', 'third-party service disruption'])}"
            ],
            "Critical Bug": [
                f"A critical bug has been identified in {random.choice(['the production environment', 'our latest release', 'the core authentication module', 'the payment processing system', 'the data synchronization process'])}.",
                f"Bug description: {random.choice(['Data corruption when processing transactions above $10k', 'Authentication bypass in specific scenarios', 'Memory leak causing gradual performance degradation', 'Race condition in concurrent operations'])}",
                f"Severity: {random.choice(['Critical - causing data loss', 'High - security vulnerability', 'Critical - service disruption', 'High - affecting major functionality'])}",
                f"Discovered by: {random.choice(['internal monitoring', 'customer report', 'security audit', 'QA team', 'operations team'])}"
            ],
            "Security Incident": [
                f"We've detected a {random.choice(['potential security breach', 'suspicious activity', 'unauthorized access attempt', 'potential data exfiltration', 'unusual system behavior'])}.",
                f"Initial assessment indicates {random.choice(['targeted attack', 'credential compromise', 'exploitation of known vulnerability', 'social engineering attempt', 'insider threat'])}.",
                f"Systems potentially affected: {', '.join(random.sample(['User database', 'Financial records', 'Authentication servers', 'Customer data', 'Internal documents'], k=random.randint(1, 3)))}",
                f"Our security team is {random.choice(['investigating the extent', 'implementing containment measures', 'working with external experts', 'assessing potential damage'])}"
            ]
        }
        
        # Default incident details for other urgent topics
        default_incident_details = [
            f"Situation started at {(self.current_date - datetime.timedelta(hours=random.randint(1, 12))).strftime('%H:%M')} and is {random.choice(['ongoing', 'escalating', 'being contained', 'under investigation'])}.",
            f"This is categorized as {random.choice(['highest priority', 'P0 incident', 'all-hands situation', 'critical business impact'])}.",
            f"Initial response has been {random.choice(['initiated', 'coordinated with key stakeholders', 'focused on containment', 'aimed at understanding the scope'])}.",
            f"We have {random.choice(['notified senior management', 'engaged specialized resources', 'activated our emergency response plan', 'started regular status updates'])}"
        ]
        
        # Get appropriate incident details or use default
        incident_details_list = incident_details.get(topic, default_incident_details)
        selected_details = random.sample(incident_details_list, k=random.randint(2, len(incident_details_list)))
        
        # Generate impact assessment
        impact_list = [
            "This is affecting all users of the system.",
            "Several key clients are impacted.",
            "The finance team cannot process transactions.",
            "Our main service is running at degraded capacity.",
            "Data integrity may be compromised.",
            "Customer-facing applications are unavailable.",
            "Sensitive data may have been exposed.",
            "Revenue-generating operations are affected.",
            "Multiple teams are blocked from normal operations.",
            "We're receiving escalated support tickets."
        ]
        
        selected_impacts = random.sample(impact_list, k=random.randint(2, 4))
        
        # Generate response plan
        response_actions = [
            "Emergency team has been assembled and is working on resolution.",
            f"We've initiated our {random.choice(['disaster recovery plan', 'incident response protocol', 'business continuity procedures', 'crisis management process'])}.",
            f"{random.choice(['Development', 'Operations', 'Security', 'Platform'])} team is implementing an emergency fix.",
            f"We've engaged {random.choice(['vendor support', 'external consultants', 'specialized expertise', 'senior architects'])} to assist.",
            f"A war room has been set up in {random.choice(['Conference Room A', 'Microsoft Teams channel', 'Slack channel', 'Zoom meeting'])}.",
            f"Regular updates will be provided every {random.choice(['30 minutes', 'hour', '2 hours'])}."
        ]
        
        selected_response = random.sample(response_actions, k=random.randint(2, 4))
        
        # Generate required actions
        required_actions = [
            "Please join the emergency call at the link below.",
            "We need all hands on deck to resolve this issue.",
            "Please respond with your availability to help resolve this.",
            "Approval needed ASAP to implement the emergency fix.",
            "Please review and approve the attached emergency plan.",
            "Key decision-makers need to convene immediately.",
            "Customer communications need urgent approval.",
            "Please designate a representative from your team to join the response effort."
        ]
        
        # Generate escalation contacts
        escalation_contacts = ""
        if random.random() < 0.7:
            contacts = [
                f"Primary incident commander: {random.choice([s['name'] for s in self.senders if 'Manager' in s.get('title', '') or 'Director' in s.get('title', '')])}, available at {random.choice(['x1234', 'mobile: 555-123-4567', 'emergency contact channel'])}",
                f"Technical lead: {random.choice([s['name'] for s in self.senders if 'Engineer' in s.get('title', '') or 'CTO' in s.get('title', '')])}, available at {random.choice(['x2345', 'mobile: 555-234-5678', 'Slack emergency channel'])}",
                f"Executive sponsor: {random.choice([s['name'] for s in self.senders if 'CEO' in s.get('title', '') or 'CFO' in s.get('title', '') or 'COO' in s.get('title', '')])}, notified and on standby",
                f"External support: {random.choice(['Vendor emergency line', 'Consultant on call', 'Partner organization'])}, ticket #{random.randint(100000, 999999)}"
            ]
            selected_contacts = random.sample(contacts, k=random.randint(2, len(contacts)))
            escalation_contacts = f"""
Escalation Contacts:
{chr(10).join("- " + contact for contact in selected_contacts)}
"""
        
        content = f"""URGENT: {topic}

{random.choice([
    f"We're experiencing a {random.choice(['major system outage', 'critical service disruption', 'significant performance issue', 'security incident', 'severe degradation of services'])}.",
    f"A critical bug has been discovered in {random.choice(['production', 'the latest release', 'the core system', 'our main platform', 'customer-facing services'])}.",
    f"Client {random.choice(['ABC Corp', 'XYZ Industries', 'MegaCorp', 'Global Enterprises', 'Tech Innovations'])} has escalated an issue to the highest level.",
    f"There's been a {random.choice(['security breach', 'potential data exposure', 'unauthorized access attempt', 'malicious activity', 'system compromise'])}.",
    f"The deadline for Project {random.choice(self.projects)} has been moved up significantly due to {random.choice(['client demand', 'market conditions', 'competitive pressures', 'executive directive'])}."
])}

Incident Details:
{chr(10).join("- " + detail for detail in selected_details)}

Impact:
{chr(10).join("- " + impact for impact in selected_impacts)}

Current Response:
{chr(10).join("- " + response for response in selected_response)}

Required Action:
{random.choice(required_actions)}

Meeting Information:
- Emergency Response Call: {random.choice(['https://meeting.link/emergency', 'Bridge Line: 888-555-1234, Access Code: 987654', 'Teams/Slack Emergency Channel', 'War Room: Conference Room A'])}
- Time: Immediate / {(self.current_date + datetime.timedelta(minutes=random.randint(15, 60))).strftime('%H:%M')}
- Expected Duration: {random.choice(['1 hour', '2 hours', 'Ongoing until resolution', 'To be determined'])}

{escalation_contacts}
{random.choice(['This requires immediate attention.', 'Please prioritize this issue.', 'Respond ASAP.', 'Time is of the essence.', 'Your immediate action is critical.'])}

{sender['name']}
{sender['title']}
Emergency Contact: {random.choice(['x1234', 'Mobile: 555-987-6543', 'Available via Slack/Teams'])}
"""
        
        return {
            "id": str(uuid.uuid4()),
            "sender": sender,
            "subject": subject,
            "content": content,
            "date": self._random_date(),
            "category": "urgent",
            "is_urgent": True
        }
    
    def _generate_fyi_email(self, sender: Dict[str, str]) -> Dict[str, Any]:
        """Generate an FYI (For Your Information) email."""
        fyi_topics = [
            "Company Announcement", "Office Update", "Policy Change", 
            "Team Changes", "New Tool Available", "Upcoming Event",
            "Procedural Update", "IT System Changes", "Industry News",
            "Training Opportunity"
        ]
        topic = random.choice(fyi_topics)
        
        subject = f"FYI: {topic}"
        
        # Generate detailed content based on topic
        topic_details = {
            "Company Announcement": [
                f"We're pleased to announce {random.choice(['our quarterly results', 'a new partnership with ' + random.choice(['Microsoft', 'Amazon', 'Google', 'Salesforce']), 'an upcoming reorganization', 'our expansion to ' + random.choice(['Europe', 'Asia', 'South America', 'new markets'])])}.",
                f"This represents a significant {random.choice(['achievement', 'milestone', 'development', 'opportunity'])} for our organization.",
                f"The announcement will be made public on {(self.current_date + datetime.timedelta(days=random.randint(1, 10))).strftime('%B %d')}.",
                f"Additional details will be shared during the all-hands meeting on {(self.current_date + datetime.timedelta(days=random.randint(1, 7))).strftime('%A')}."
            ],
            "Office Update": [
                f"The {random.choice(['main office', 'headquarters', 'satellite office', 'remote work policy'])} will be {random.choice(['renovated', 'relocated', 'closed for maintenance', 'expanded'])} starting {(self.current_date + datetime.timedelta(days=random.randint(7, 30))).strftime('%B %d')}.",
                f"During this time, {random.choice(['alternative arrangements', 'temporary workspaces', 'remote work options', 'flexible scheduling'])} will be available.",
                f"The project is expected to last approximately {random.randint(2, 12)} {random.choice(['weeks', 'months'])}.",
                f"Please refer to the {random.choice(['attached document', 'intranet', 'follow-up email', 'department manager'])} for specific details relevant to your team."
            ],
            "Policy Change": [
                f"Effective {(self.current_date + datetime.timedelta(days=random.randint(7, 30))).strftime('%B %d')}, we're updating our {random.choice(['remote work', 'expense reporting', 'vacation', 'security', 'code review', 'deployment'])} policy.",
                f"Key changes include: {random.choice(['more flexible hours', 'simplified approval process', 'additional documentation requirements', 'enhanced security protocols', 'streamlined procedures'])}.",
                f"This change is based on {random.choice(['employee feedback', 'industry best practices', 'regulatory requirements', 'operational efficiency improvements'])}.",
                f"Training sessions will be organized to ensure smooth transition."
            ],
            "Team Changes": [
                f"We're {random.choice(['welcoming', 'congratulating', 'saying goodbye to', 'recognizing'])} {random.choice([s['name'] for s in self.senders])} who will be {random.choice(['joining our team', 'taking on a new role', 'leaving the company', 'celebrating 5 years with us'])}.",
                f"This change will be effective from {(self.current_date + datetime.timedelta(days=random.randint(1, 14))).strftime('%B %d')}.",
                f"{random.choice(['A welcome lunch', 'A farewell gathering', 'A team celebration', 'An introduction meeting'])} is planned for {(self.current_date + datetime.timedelta(days=random.randint(1, 7))).strftime('%A')} at {random.randint(11, 16) % 12 or 12}:{random.choice(['00', '30'])} {random.choice(['AM', 'PM'])}.",
                f"Please {random.choice(['join us in welcoming them', 'wish them well in their future endeavors', 'congratulate them on their achievement', 'reach out to introduce yourself'])}"
            ]
        }
        
        # Default details for other FYI topics
        default_details = [
            f"This information is being shared to {random.choice(['keep you informed', 'ensure transparency', 'maintain alignment', 'prepare for upcoming changes'])}.",
            f"The details have been {random.choice(['carefully reviewed', 'approved by management', 'coordinated with relevant teams', 'planned over several weeks'])}.",
            f"Implementation will begin on {(self.current_date + datetime.timedelta(days=random.randint(1, 14))).strftime('%B %d')}.",
            f"For questions, please contact {random.choice([s['name'] for s in self.senders])}"
        ]
        
        # Get appropriate details or use default
        details_list = topic_details.get(topic, default_details)
        selected_details = random.sample(details_list, k=random.randint(2, len(details_list)))
        
        # Generate additional information
        additional_info_options = [
            f"Documentation is available on the {random.choice(['company intranet', 'shared drive', 'knowledge base', 'team wiki'])}.",
            f"A {random.choice(['detailed presentation', 'Q&A session', 'training workshop', 'feedback forum'])} is scheduled for next week.",
            f"This aligns with our {random.choice(['quarterly objectives', 'strategic initiatives', 'organizational values', 'department goals'])}.",
            f"We anticipate this will {random.choice(['improve efficiency', 'enhance collaboration', 'reduce overhead', 'streamline processes'])}."
        ]
        
        selected_additional_info = random.sample(additional_info_options, k=random.randint(1, 2))
        
        # Generate resources section
        resources = ""
        if random.random() < 0.5:
            resource_options = [
                f"More information: {random.choice(['Internal wiki page', 'Detailed documentation', 'Training videos', 'FAQ document'])}",
                f"Contact person: {random.choice([s['name'] for s in self.senders])} ({random.choice(['x1234'] + [s['email'] for s in self.senders])})",
                f"Relevant links: {random.choice(['Company intranet', 'Project site', 'Training platform', 'Support portal'])}",
                f"Next steps: {random.choice(['Review documentation', 'Attend information session', 'Update your calendar', 'Complete required training'])}"
            ]
            selected_resources = random.sample(resource_options, k=random.randint(2, len(resource_options)))
            
            resources = f"""
Resources:
{chr(10).join("- " + resource for resource in selected_resources)}
"""
        
        content = f"""FYI - {topic}

{random.choice([
    f"Just wanted to let you know that {random.choice(['the office will be closed', 'we have a new team member', 'there are changes to the vacation policy', 'we have updated our tools', 'a new project is starting', 'a significant milestone has been achieved'])}.",
    f"For your information, {random.choice(['we will be upgrading our systems', 'there will be a company event', 'we have new security protocols', 'there are changes to the project timeline', 'a new client has come onboard', 'quarterly planning is underway'])}.",
    f"Please note that {random.choice(['the quarterly review is approaching', 'we have new documentation available', 'there are updates to the employee handbook', 'we have a new client joining', 'important deadlines are coming up', 'a system maintenance is scheduled'])}."
])}

Details:
{chr(10).join("- " + detail for detail in selected_details)}

{chr(10).join(selected_additional_info)}

{resources}
Timeline:
- Announcement date: {self.current_date.strftime('%B %d, %Y')}
- Effective date: {(self.current_date + datetime.timedelta(days=random.randint(1, 30))).strftime('%B %d, %Y')}

{random.choice(['No action is required.', 'This is just for your information.', 'Feel free to reach out if you have questions.', 'Keep this information in mind for future reference.'])}

{random.choice(['Best regards', 'Thanks', 'Regards', 'Best', 'With appreciation'])}
{sender['name']}
{sender['title']}
"""
        
        return {
            "id": str(uuid.uuid4()),
            "sender": sender,
            "subject": subject,
            "content": content,
            "date": self._random_date(),
            "category": "fyi",
            "is_urgent": False
        }
    
    def _generate_newsletter_email(self, sender: Dict[str, str]) -> Dict[str, Any]:
        """Generate a newsletter email."""
        if random.random() < 0.7:
            sender = {"name": "Newsletter", "email": "news@industry.com", "title": "Industry Updates"}
        
        newsletter_topics = [
            "Industry Updates", "Weekly Digest", "Tech News", 
            "Corporate Newsletter", "Market Trends", "Product Updates",
            "Innovation Spotlight", "Business Intelligence", "Research Findings",
            "Professional Development"
        ]
        topic = random.choice(newsletter_topics)
        
        subject = f"Newsletter: {topic} - {self.current_date.strftime('%b %Y')}"
        
        # Generate featured article
        featured_article_titles = [
            f"The Future of {random.choice(['AI', 'Remote Work', 'Digital Marketing', 'Cloud Computing', 'IoT', 'Blockchain', 'Sustainable Business'])}",
            f"{random.choice(['Rising', 'Emerging', 'Growing', 'Important'])} Trends in {random.choice(['Technology', 'Business', 'Healthcare', 'Finance', 'E-commerce', 'Manufacturing'])}",
            f"How {random.choice(['Companies', 'Leaders', 'Innovators', 'Startups'])} Are Adapting to {random.choice(['Market Changes', 'New Regulations', 'Digital Transformation', 'Global Challenges'])}",
            f"{random.choice(['Analysis', 'Insights', 'Deep Dive'])}: {random.choice(['Industry Disruption', 'Quarterly Performance', 'Economic Forecast', 'Technological Innovation'])}"
        ]
        
        featured_article = random.choice(featured_article_titles)
        
        featured_content = f"""
**{featured_article}**

{random.choice([
    f"Recent developments in {random.choice(['artificial intelligence', 'cloud technology', 'machine learning', 'data analytics'])} are transforming how businesses operate.",
    f"A new study by {random.choice(['McKinsey', 'Gartner', 'Forrester', 'Deloitte'])} reveals changing market dynamics that will affect strategies in the coming year.",
    f"Industry leaders are adopting {random.choice(['innovative approaches', 'new methodologies', 'cutting-edge tools', 'strategic initiatives'])} to address evolving challenges.",
    f"The latest {random.choice(['quarterly reports', 'market research', 'industry analysis', 'economic indicators'])} point to significant shifts in consumer behavior."
])}

{random.choice([
    f"Key findings indicate a {random.randint(10, 30)}% increase in {random.choice(['adoption rates', 'market penetration', 'customer engagement', 'operational efficiency'])}.",
    f"Experts predict that {random.choice(['remote work', 'digital transformation', 'sustainability initiatives', 'customer experience focus'])} will continue to be a priority in {self.current_date.year}.",
    f"Organizations that have implemented these changes report {random.choice(['improved productivity', 'cost savings', 'higher customer satisfaction', 'better employee retention'])}.",
    f"The shift toward {random.choice(['automated solutions', 'data-driven decision making', 'customer-centric approaches', 'agile methodologies'])} is accelerating across industries."
])}
"""
        
        # Generate news items
        news_items = []
        news_options = [
            f"{random.choice(['New Market Trends Emerging', 'Industry Leader Announces Merger', 'Technological Breakthrough Reported', 'Regulatory Changes Ahead', 'Major Investment in Innovation', 'Startup Receives Record Funding'])}",
            f"{random.choice(['Company X Launches Revolutionary Product', 'Survey Shows Changing Customer Preferences', 'New Research Findings Published', 'Future Outlook for Q3', 'Strategic Partnership Announced', 'Global Expansion Plans Revealed'])}",
            f"{random.choice(['Best Practices for Remote Work', 'Cybersecurity Tips for Businesses', 'Improving Team Collaboration', 'Sustainability Initiatives Gaining Momentum', 'Talent Acquisition Strategies', 'Digital Marketing Transformation'])}",
            f"{random.choice(['Industry Spotlight: Healthcare Innovation', 'Financial Markets: Quarterly Review', 'Tech Sector Growth Continues', 'Supply Chain Resilience Strategies', 'Customer Experience Transformation', 'Workplace Culture Trends'])}",
            f"{random.choice(['AI Implementation Success Stories', 'Cloud Migration Case Studies', 'Data Privacy Regulations Update', 'Automation Trends and Insights', 'Inclusive Leadership Practices', 'Business Continuity Planning'])}"
        ]
        
        selected_news = random.sample(news_options, k=random.randint(3, 5))
        
        for i, news in enumerate(selected_news, 1):
            detail = random.choice([
                f"{random.choice(['According to recent reports', 'Industry analysts suggest', 'Market research indicates', 'Experts believe'])} this trend will continue through {self.current_date.year}.",
                f"This development affects {random.choice(['multiple sectors', 'key stakeholders', 'market leaders', 'emerging businesses'])} and presents {random.choice(['new opportunities', 'significant challenges', 'strategic advantages', 'competitive pressures'])}.",
                f"Early adopters have reported {random.choice(['significant improvements', 'positive outcomes', 'promising results', 'competitive advantages'])} after implementation.",
                f"Organizations are advised to {random.choice(['monitor these developments', 'consider strategic adjustments', 'evaluate potential impacts', 'explore implementation options'])}."
            ])
            
            news_items.append(f"{i}. **{news}**\n   {detail}")
        
        # Generate upcoming events
        events = []
        event_options = [
            f"{random.choice(['Annual Industry Conference', 'Tech Summit', 'Leadership Symposium', 'Innovation Expo', 'Professional Workshop', 'Virtual Summit'])}",
            f"{random.choice(['Quarterly Earnings Call', 'Product Launch Event', 'Networking Reception', 'Certification Training', 'Panel Discussion', 'Executive Roundtable'])}",
            f"{random.choice(['Webinar Series', 'Strategy Briefing', 'Tech Demo Day', 'Hackathon', 'Thought Leadership Forum', 'Career Development Workshop'])}"
        ]
        
        if random.random() < 0.6:
            selected_events = random.sample(event_options, k=random.randint(2, 3))
            event_months = [self.current_date + datetime.timedelta(days=random.randint(10, 60)) for _ in range(len(selected_events))]
            
            for event, date in zip(selected_events, event_months):
                location = random.choice(['Virtual', 'New York', 'San Francisco', 'London', 'Singapore', 'Hybrid (In-person/Online)'])
                events.append(f"- **{event}** - {date.strftime('%B %d')}, {location}")
        
        # Generate resource section
        resources = []
        resource_options = [
            f"**White Paper**: {random.choice(['Future of Work', 'Digital Transformation Guide', 'Industry Outlook', 'Technology Adoption Roadmap', 'Strategic Planning Framework'])}",
            f"**Case Study**: {random.choice(['Success Story: Company X', 'Implementation Best Practices', 'ROI Analysis', 'Transformation Journey', 'Change Management'])}",
            f"**Podcast**: {random.choice(['Leadership Insights', 'Innovation Conversations', 'Market Perspectives', 'Tech Talk', 'Strategy Sessions'])}",
            f"**Tool**: {random.choice(['Productivity Enhancement', 'Project Management', 'Data Visualization', 'Collaboration Platform', 'Analytics Dashboard'])}"
        ]
        
        if random.random() < 0.7:
            selected_resources = random.sample(resource_options, k=random.randint(2, 3))
            resources = selected_resources
        
        # Create the email content
        events_section = ""
        if events:
            events_section = f"""
Upcoming Events:
{chr(10).join(events)}
"""

        resources_section = ""
        if resources:
            resources_section = f"""
Resources:
{chr(10).join(resources)}
"""

        content = f"""Monthly {topic} Newsletter - {self.current_date.strftime('%B %Y')}

{random.choice([
    "Here are the latest updates in our industry:",
    "We're pleased to bring you this month's digest:",
    "Check out what's happening in the world of tech:",
    "Stay informed with our monthly roundup:"
])}

Featured Article:
{featured_content}

Top Stories:
{chr(10).join(news_items)}
{events_section}
{resources_section}
Industry Insights:
{random.choice([
    f"The {random.choice(['technology', 'healthcare', 'finance', 'retail', 'manufacturing'])} sector is experiencing {random.choice(['rapid growth', 'significant transformation', 'increasing challenges', 'new opportunities'])}.",
    f"Organizations focusing on {random.choice(['customer experience', 'operational efficiency', 'innovation', 'sustainability'])} are seeing {random.choice(['improved results', 'competitive advantages', 'market leadership', 'stronger performance'])}.",
    f"Investment in {random.choice(['digital capabilities', 'workforce development', 'research and development', 'strategic partnerships'])} remains a priority for industry leaders.",
    f"Market analysts predict {random.choice(['continued growth', 'increased competition', 'emerging opportunities', 'evolving customer demands'])} in the coming quarter."
])}

{random.choice(['Read more on our website.', 'Click below for detailed articles.', 'Subscribe for daily updates.', 'Visit our knowledge center for more insights.'])}

{random.choice(['Best regards', 'Thanks for reading', 'Until next time', 'Stay informed', 'Wishing you continued success'])}
{topic} Team

---
To unsubscribe or manage your email preferences, click here.
This newsletter is provided for informational purposes only and does not constitute professional advice."""
        
        return {
            "id": str(uuid.uuid4()),
            "sender": sender,
            "subject": subject,
            "content": content,
            "date": self._random_date(),
            "category": "newsletter",
            "is_urgent": False
        }
    
    def generate_emails(self, count: int = 200) -> List[Dict[str, Any]]:
        """Generate a specified number of random corporate emails."""
        emails = []
        email_type_choices = []
        for email_type in self.email_types:
            email_type_choices.extend([email_type["type"]] * email_type["weight"])
        
        for _ in range(count):
            email_type = random.choice(email_type_choices)
            sender = random.choice(self.senders)
            
            if email_type == "meeting":
                email = self._generate_meeting_email(sender)
            elif email_type == "update":
                email = self._generate_update_email(sender)
            elif email_type == "request":
                email = self._generate_request_email(sender)
            elif email_type == "urgent":
                email = self._generate_urgent_email(sender)
            elif email_type == "fyi":
                email = self._generate_fyi_email(sender)
            elif email_type == "newsletter":
                email = self._generate_newsletter_email(sender)
            
            emails.append(email)
        
        # Sort by date, most recent first
        emails.sort(key=lambda x: x["date"], reverse=True)
        
        return emails

# If running this file directly, generate and print a sample email
if __name__ == "__main__":
    generator = MockEmailGenerator()
    sample_emails = generator.generate_emails(3)
    
    for email in sample_emails:
        print(f"Subject: {email['subject']}")
        print(f"From: {email['sender']['name']} <{email['sender']['email']}>")
        print(f"Date: {email['date'].strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Category: {email['category']}")
        print(f"Priority: {'Urgent' if email['is_urgent'] else 'Normal'}")
        print("\nContent:")
        print(email['content'])
        print("-" * 80) 