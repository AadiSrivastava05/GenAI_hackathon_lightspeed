import imaplib
import email
import datetime
import uuid
import os
import time
from email.header import decode_header
from email.utils import parsedate_to_datetime
from typing import List, Dict, Any
import logging
from dotenv import load_dotenv
import hashlib

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class RealEmailProvider:
    """
    Connect to a real email provider using IMAP and retrieve emails.
    """
    
    def __init__(self):
        # Ensure environment variables are loaded
        load_dotenv(override=True)
        
        # Get credentials from environment variables
        self.email = os.environ.get('EMAIL_ADDRESS')
        self.password = os.environ.get('EMAIL_PASSWORD')
        self.imap_server = os.environ.get('IMAP_SERVER')
        self.imap_port = int(os.environ.get('IMAP_PORT', 993))
        
        # Debug log credentials (safely)
        logger.info(f"Initializing email provider with: Email={self.email or 'NOT SET'}, "
                    f"Server={self.imap_server or 'NOT SET'}, "
                    f"Password={'SET' if self.password else 'NOT SET'}")
        
        # Validate credentials
        if not all([self.email, self.password, self.imap_server]):
            raise ValueError("Email credentials not properly configured in .env file")
        
        # Validate the email server is one we can connect to
        supported_servers = {
            'outlook.office365.com': 'Outlook/Office365',
            'imap.gmail.com': 'Gmail',
            'imap.mail.yahoo.com': 'Yahoo Mail',
            'imap.aol.com': 'AOL',
            'imap-mail.outlook.com': 'Outlook.com'
        }
        
        if self.imap_server not in supported_servers:
            logger.warning(f"Using untested IMAP server: {self.imap_server}")
        else:
            logger.info(f"Using {supported_servers[self.imap_server]} email provider")
        
        # Connection tracking and retry settings
        self.connection_attempts = 0
        self.max_connection_attempts = 3
        self.connection_retry_delay = 2  # seconds
    
    def _connect_to_mailbox(self):
        """Establish connection to the IMAP server with retry logic."""
        while self.connection_attempts < self.max_connection_attempts:
            try:
                # Create an IMAP4 class with SSL 
                mail = imaplib.IMAP4_SSL(self.imap_server, self.imap_port)
                
                # Authenticate
                mail.login(self.email, self.password)
                logger.info(f"Successfully connected to {self.imap_server}")
                self.connection_attempts = 0  # Reset counter on success
                return mail
            except imaplib.IMAP4.error as imap_err:
                self.connection_attempts += 1
                logger.error(f"IMAP error (attempt {self.connection_attempts}/{self.max_connection_attempts}): {str(imap_err)}")
                if self.connection_attempts >= self.max_connection_attempts:
                    raise
                time.sleep(self.connection_retry_delay)
            except Exception as e:
                self.connection_attempts += 1
                logger.error(f"Error connecting to email server (attempt {self.connection_attempts}/{self.max_connection_attempts}): {str(e)}")
                if self.connection_attempts >= self.max_connection_attempts:
                    raise
                time.sleep(self.connection_retry_delay)
        
        # If we get here, we've exceeded max attempts
        raise ConnectionError(f"Failed to connect to {self.imap_server} after {self.max_connection_attempts} attempts")
    
    def _decode_email_subject(self, subject):
        """Decode email subject properly."""
        if subject is None:
            return "No Subject"
        
        decoded_parts = []
        for content, encoding in decode_header(subject):
            if isinstance(content, bytes):
                # If it's bytes, decode with the specified encoding or default to utf-8
                try:
                    decoded_parts.append(content.decode(encoding or 'utf-8', errors='replace'))
                except:
                    decoded_parts.append(content.decode('utf-8', errors='replace'))
            else:
                decoded_parts.append(content)
        
        return ''.join(decoded_parts)
    
    def _get_email_body(self, msg):
        """Extract the email body text content."""
        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                content_disposition = str(part.get("Content-Disposition"))
                
                # Skip attachments
                if "attachment" in content_disposition:
                    continue
                
                # Extract text content
                if content_type == "text/plain":
                    try:
                        body = part.get_payload(decode=True).decode('utf-8', errors='replace')
                        return body
                    except:
                        pass
                
                # If no text/plain, try HTML (but we'll want to strip HTML tags in a real app)
                elif content_type == "text/html":
                    try:
                        body = part.get_payload(decode=True).decode('utf-8', errors='replace')
                        # In a complete implementation, strip HTML tags here
                        return body
                    except:
                        pass
        else:
            # Not multipart, get content directly
            content_type = msg.get_content_type()
            if content_type == "text/plain" or content_type == "text/html":
                try:
                    body = msg.get_payload(decode=True).decode('utf-8', errors='replace')
                    return body
                except:
                    pass
        
        return "Unable to extract email content"
    
    def _extract_sender_info(self, from_header):
        """Extract sender name and email from From header."""
        if not from_header:
            return {"name": "Unknown", "email": "unknown@example.com", "title": ""}
        
        # Parse the 'From' header
        try:
            # Try to extract name and email
            if '<' in from_header and '>' in from_header:
                name = from_header.split('<')[0].strip().strip('"').strip("'")
                email_address = from_header.split('<')[1].split('>')[0]
                
                # Title is not typically in email headers, would need to be looked up elsewhere
                title = ""
            else:
                # If no angle brackets, the whole thing is the email
                name = from_header.split('@')[0]
                email_address = from_header
                title = ""
            
            return {"name": name, "email": email_address, "title": title}
        except:
            # Fallback if parsing fails
            return {"name": from_header, "email": "unknown@example.com", "title": ""}
    
    def _determine_priority(self, msg):
        """Determine if an email is urgent based on headers and subject."""
        subject = self._decode_email_subject(msg["Subject"])
        
        # Check priority headers
        priority = msg.get("X-Priority", "3")
        importance = msg.get("Importance", "normal")
        
        # Check subject for urgent keywords
        urgent_keywords = ['urgent', 'important', 'asap', 'emergency', 'critical', 'priority']
        subject_lower = subject.lower()
        
        # Check if any urgent keywords in subject
        subject_indicates_urgent = any(keyword in subject_lower for keyword in urgent_keywords)
        
        # Determine urgency based on headers and subject
        is_urgent = (
            subject_indicates_urgent or
            priority in ['1', '2'] or
            importance.lower() == 'high'
        )
        
        return is_urgent
    
    def get_emails(self, count=200, folder='INBOX') -> List[Dict[str, Any]]:
        """
        Retrieve emails from the specified folder.
        
        Args:
            count (int): Maximum number of emails to retrieve
            folder (str): Email folder to retrieve from (default: INBOX)
            
        Returns:
            List[Dict[str, Any]]: List of email dictionaries
        """
        mail = None
        emails = []
        
        try:
            # Connect to mailbox with retry logic
            mail = self._connect_to_mailbox()
            
            # Select the mailbox/folder
            status, messages = mail.select(folder)
            if status != 'OK':
                logger.error(f"Failed to select folder {folder}")
                return []
            
            # Get total number of emails
            messages = int(messages[0])
            logger.info(f"Found {messages} emails in {folder}")
            
            # Calculate how many emails to retrieve (handle case of 0 emails)
            if messages == 0:
                logger.warning(f"No emails found in {folder}")
                return []
                
            num_to_fetch = min(messages, count)
            
            # Get the latest 'count' emails
            start_idx = max(1, messages - num_to_fetch + 1)
            end_idx = messages
            
            # Create the range string for fetching emails
            if start_idx == end_idx:
                fetch_range = str(start_idx)
            else:
                fetch_range = f"{start_idx}:{end_idx}"
            
            # Fetch emails
            logger.info(f"Fetching emails {start_idx} to {end_idx}")
            status, email_ids = mail.search(None, 'ALL')
            
            if status != 'OK' or not email_ids[0]:
                logger.warning("No email IDs returned from search")
                return []
                
            # Extract ID numbers from search response
            id_list = email_ids[0].split()
            
            # Limit to the most recent 'count' emails
            if len(id_list) > count:
                id_list = id_list[-count:]
            
            for email_id in reversed(id_list):  # Process newest first
                try:
                    # Fetch email
                    status, msg_data = mail.fetch(email_id, '(RFC822)')
                    
                    if status != 'OK':
                        logger.warning(f"Failed to fetch email ID {email_id}")
                        continue
                    
                    # Parse email content
                    raw_email = msg_data[0][1]
                    msg = email.message_from_bytes(raw_email)
                    
                    # Extract email date
                    date_str = msg.get("Date")
                    if date_str:
                        try:
                            email_date = parsedate_to_datetime(date_str)
                        except:
                            email_date = datetime.datetime.now()
                    else:
                        email_date = datetime.datetime.now()
                    
                    # Extract subject
                    subject = self._decode_email_subject(msg["Subject"])
                    
                    # Extract sender information
                    sender = self._extract_sender_info(msg["From"])
                    
                    # Extract email body
                    content = self._get_email_body(msg)
                    
                    # Determine if email is urgent
                    is_urgent = self._determine_priority(msg)
                    
                    # Create email object
                    email_obj = {
                        "id": self._generate_stable_id(msg),  # Generate a stable ID
                        "subject": subject,
                        "content": content,
                        "sender": sender,
                        "date": email_date,
                        "is_urgent": is_urgent,
                        "category": "urgent" if is_urgent else "normal",
                        # We'll add the summary later when needed
                    }
                    
                    emails.append(email_obj)
                except Exception as e:
                    logger.error(f"Error processing email ID {email_id}: {str(e)}")
                    continue  # Skip this email and continue with next one
            
            logger.info(f"Successfully retrieved {len(emails)} emails")
            
        except Exception as e:
            logger.error(f"Error retrieving emails: {str(e)}")
            # Continue execution to ensure we properly close the connection
        
        finally:
            # Ensure the connection is properly closed
            if mail:
                try:
                    mail.close()
                    mail.logout()
                except:
                    pass  # Ignore errors during cleanup
            
        return emails 

    def _generate_stable_id(self, msg):
        """Generate a stable ID for an email based on its properties."""
        # Try to use Message-ID if available
        message_id = msg.get("Message-ID")
        if message_id:
            # Clean up the message ID to make it suitable for a URL
            clean_id = message_id.strip("<>").replace("@", "-at-").replace(".", "-dot-")
            return f"email-{clean_id}"
        
        # Fallback to a combination of subject, date, and sender
        subject = self._decode_email_subject(msg.get("Subject", ""))
        date = msg.get("Date", "")
        sender = msg.get("From", "")
        
        # Create a combined string and hash it
        combined = f"{subject}|{date}|{sender}"
        hashed = hashlib.md5(combined.encode()).hexdigest()
        
        return f"email-{hashed}" 