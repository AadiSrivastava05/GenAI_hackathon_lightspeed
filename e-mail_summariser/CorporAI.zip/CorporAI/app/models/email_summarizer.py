import google.generativeai as genai
import os
import time
from dotenv import load_dotenv

# Ensure environment variables are loaded
load_dotenv(override=True)

class EmailSummarizer:
    def __init__(self):
        # Initialize the Gemini API
        genai.configure(api_key=os.environ.get('GEMINI_API_KEY', 'your-api-key-here'))
        self.model = genai.GenerativeModel('gemini-2.0-flash')
    
    def summarize(self, email_content):
        """
        Summarize a single email content.
        
        Args:
            email_content (str): The content of the email to summarize
            
        Returns:
            str: A concise summary of the email
        """
        prompt = f"""
        Summarize the following email in a concise manner. Highlight any important keywords, 
        dates, action items, or critical information. Keep your summary brief but informative. Word limit: 100 words.
        No markdown formatting.
        EMAIL:
        {email_content}
        """
        
        try:
            response = self.model.generate_content(prompt)
            return response.text
        except Exception as e:
            print(f"Error summarizing email: {e}")
            return "Failed to summarize email."
    
    def meta_summarize(self, high_priority_emails):
        """
        Generate a meta-summary of all high priority emails.
        
        Args:
            high_priority_emails (list): List of high priority email dictionaries
            
        Returns:
            str: A comprehensive summary of all high priority emails
        """
        if not high_priority_emails:
            return "No high priority emails to summarize."
        
        # Extract information from emails
        email_info = []
        for i, email in enumerate(high_priority_emails):
            # Check if the email has a summary, if not, include the full content
            if 'summary' not in email:
                email_info.append(f"""Email {i+1}:
Subject: {email['subject']}
Full Content:
{email['content']}""")
            else:
                email_info.append(f"""Email {i+1}:
Subject: {email['subject']}
Summary: {email['summary']}""")
        
        # Join all email summaries
        all_emails = "\n\n".join(email_info)
        
        prompt = f"""
        You are reviewing high priority emails for a corporate professional. 
        Create a comprehensive executive summary of the following high priority emails.
        Group related topics together, highlight urgent action items, and provide a strategic overview.
        
        HIGH PRIORITY EMAILS:
        {all_emails}
        
        In your meta-summary:
        1. Group related emails by topic
        2. Highlight any urgent action items or deadlines
        3. Note recurring themes or issues
        4. Keep the summary concise but comprehensive
        5. Format your response using markdown (headings with ##, bold with **, bullet points with -)
        """
        
        # Add delay before the API call to avoid rate limiting
        time.sleep(1)
        
        try:
            response = self.model.generate_content(prompt)
            return response.text
        except Exception as e:
            print(f"Error creating meta-summary: {e}")
            return "Failed to create summary of high priority emails." 