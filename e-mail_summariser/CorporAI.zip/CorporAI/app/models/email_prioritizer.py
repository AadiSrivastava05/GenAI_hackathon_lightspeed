import google.generativeai as genai
import os
from dotenv import load_dotenv

# Ensure environment variables are loaded
load_dotenv(override=True)

class EmailPrioritizer:
    def __init__(self):
        # Initialize the Gemini API
        genai.configure(api_key=os.environ.get('GEMINI_API_KEY', 'your-api-key-here'))
        self.model = genai.GenerativeModel('gemini-2.0-flash')
    
    def classify(self, email_subject, email_content):
        """
        Classify the email as high, medium, or low priority based on its content and subject.
        
        Args:
            email_subject (str): The subject of the email
            email_content (str): The content of the email
            
        Returns:
            str: The priority level ("high", "medium", or "low")
        """
        prompt = f"""
        Classify the following email as high priority, medium priority, or low priority.
        
        Consider these factors for high priority:
        - Emails from executives, managers, or important clients
        - Urgent deadlines or time-sensitive matters
        - Critical business issues or emergencies
        - Keywords like "urgent", "ASAP", "important", "deadline"
        
        Consider these factors for medium priority:
        - Regular project updates
        - Questions requiring attention but not immediately
        - Regular client communications
        
        Consider these factors for low priority:
        - Newsletters
        - Non-urgent FYI emails
        - Social notifications
        - Marketing emails
        
        Return only "high", "medium", or "low" as your answer.
        
        EMAIL SUBJECT: {email_subject}
        
        EMAIL CONTENT:
        {email_content}
        """
        
        try:
            response = self.model.generate_content(prompt)
            priority = response.text.strip().lower()
            
            # Normalize the response
            if "high" in priority:
                return "high"
            elif "medium" in priority or "mid" in priority:
                return "medium"
            else:
                return "low"
        except Exception as e:
            print(f"Error classifying email: {e}")
            return "medium"  # Default to medium priority in case of error 