from typing import List, Dict, Any
from app.models.gemini_email_generator import GeminiEmailGenerator
import os
import pickle
import logging
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class EmailStore:
    """
    Storage and retrieval of emails.
    Priorities:
    1. Try to use real emails via IMAP if credentials are available
    2. Fall back to Gemini API to generate realistic emails
    3. Final fallback to mock emails if needed
    """
    
    def __init__(self):
        # Force reload environment variables
        load_dotenv(override=True)
        
        self.cache_file = os.path.join(os.path.dirname(__file__), 'generated_emails.pkl')
        self.emails = []
        self.high_priority_emails = []
        self.using_real_emails = False
        
        # Try to use real email provider first - check for credentials beforehand
        if self._check_email_credentials():
            self._try_real_email_provider()
        else:
            logger.info("Email credentials not fully configured in environment. Falling back to generated emails.")
        
        # If no emails were loaded, check for cached emails
        if not self.emails and os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'rb') as f:
                    self.emails = pickle.load(f)
                    logger.info(f"Loaded {len(self.emails)} emails from cache.")
            except Exception as e:
                logger.error(f"Error loading cached emails: {str(e)}")
                # Fall back to regenerating emails
                self._generate_emails()
        # If still no emails, generate them
        elif not self.emails:
            self._generate_emails()
        
        # Track the high priority emails
        self.high_priority_emails = [email for email in self.emails if email["is_urgent"]]
        
        # Keep only the last 50 high priority emails
        self.high_priority_emails = self.high_priority_emails[:50]
    
    def _check_email_credentials(self):
        """Check if email credentials are available in environment."""
        email_address = os.environ.get('EMAIL_ADDRESS')
        email_password = os.environ.get('EMAIL_PASSWORD')
        imap_server = os.environ.get('IMAP_SERVER')
        
        # All three must be present to use real email
        return bool(email_address and email_password and imap_server)
    
    def _try_real_email_provider(self):
        """Try to load real emails from the configured email provider."""
        try:
            # Credentials already validated in _check_email_credentials
            logger.info("Email credentials found. Attempting to use real email provider.")
            
            # Import real email provider
            from app.models.real_email_provider import RealEmailProvider
            
            # Create the provider and get emails
            provider = RealEmailProvider()
            real_emails = provider.get_emails(200)
            
            if real_emails:
                self.emails = real_emails
                self.using_real_emails = True
                logger.info(f"Successfully loaded {len(real_emails)} real emails.")
                # Don't cache real emails to avoid storing sensitive data
                return True
            else:
                logger.warning("Real email provider returned no emails. Falling back to generated emails.")
        except Exception as e:
            logger.error(f"Error using real email provider: {str(e)}")
            logger.info("Falling back to generated emails.")
        
        return False
    
    def _generate_emails(self):
        """Generate emails using Gemini API and store them."""
        try:
            logger.info("Attempting to generate emails with Gemini API...")
            generator = GeminiEmailGenerator()
            self.emails = generator.generate_emails(200)
            logger.info(f"Successfully generated {len(self.emails)} emails with Gemini API.")
        except Exception as e:
            logger.error(f"Failed to generate emails with Gemini API: {str(e)}")
            logger.info("Falling back to mock emails...")
            
            # Import mock emails only if needed (fallback)
            from app.models.mock_emails import MockEmailGenerator
            mock_generator = MockEmailGenerator()
            self.emails = mock_generator.generate_emails(200)
            logger.info(f"Generated {len(self.emails)} mock emails as fallback.")
            
            # Save the mock emails to cache to avoid regeneration
            try:
                with open(self.cache_file, 'wb') as f:
                    pickle.dump(self.emails, f)
                logger.info("Saved mock emails to cache for future use.")
            except Exception as cache_error:
                logger.error(f"Failed to cache mock emails: {str(cache_error)}")
    
    def get_all_emails(self, refresh=False) -> List[Dict[str, Any]]:
        """Get all emails.
        
        Args:
            refresh (bool): Whether to force refresh emails from provider
        """
        # If we're using real emails and refresh is requested, refresh them
        if self.using_real_emails and self._check_email_credentials() and refresh:
            try:
                from app.models.real_email_provider import RealEmailProvider
                provider = RealEmailProvider()
                real_emails = provider.get_emails(200)
                if real_emails:
                    self.emails = real_emails
                    # Update high priority emails also
                    self.high_priority_emails = [email for email in self.emails if email["is_urgent"]]
                    self.high_priority_emails = self.high_priority_emails[:50]
                    logger.debug("Refreshed real emails from provider")
            except Exception as e:
                logger.error(f"Error refreshing real emails: {str(e)}")
        
        return self.emails
    
    def get_email(self, email_id: str) -> Dict[str, Any]:
        """Get a specific email by ID."""
        for email in self.emails:
            if email["id"] == email_id:
                return email
        return None
    
    def get_high_priority_emails(self) -> List[Dict[str, Any]]:
        """Get the list of high priority emails."""
        return self.high_priority_emails
    
    def add_high_priority_email(self, email: Dict[str, Any]) -> None:
        """Add an email to the high priority list."""
        self.high_priority_emails.insert(0, email)
        
        # Keep only the last 50 high priority emails
        if len(self.high_priority_emails) > 50:
            self.high_priority_emails = self.high_priority_emails[:50] 