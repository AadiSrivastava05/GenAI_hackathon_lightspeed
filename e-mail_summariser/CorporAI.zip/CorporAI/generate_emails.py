#!/usr/bin/env python
"""
Email Generation Utility for CorporAI
This script generates synthetic emails using the Gemini API and saves them to a cache file.
"""

import os
import sys
import time
from dotenv import load_dotenv
import pickle
import google.generativeai as genai
from app.models.gemini_email_generator import GeminiEmailGenerator

def check_environment():
    """Check if the environment is properly set up."""
    # Load environment variables
    load_dotenv()
    
    # Check API key
    api_key = os.environ.get('GEMINI_API_KEY')
    if not api_key:
        print("ERROR: GEMINI_API_KEY not found in environment variables.")
        print("Please set it in your .env file or environment.")
        return False
    
    if api_key == 'your-api-key-here':
        print("ERROR: GEMINI_API_KEY is set to the placeholder value.")
        print("Please update it with your actual API key.")
        return False
    
    print(f"Found API key ending with ...{api_key[-4:]}")
    
    # Validate API key format (should be a long string)
    if len(api_key) < 20:
        print(f"WARNING: API key length ({len(api_key)}) seems suspiciously short.")
    
    # Test API connection
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-2.0-flash')
        response = model.generate_content("Hello, this is a test.")
        print("Successfully connected to Gemini API!")
        return True
    except Exception as e:
        print(f"ERROR: Could not connect to Gemini API: {str(e)}")
        return False

def generate_emails(count=200, force=False, rate_limit=6, batch_size=10):
    """Generate emails and cache them."""
    cache_path = os.path.join(os.path.dirname(__file__), 'app', 'models', 'generated_emails.pkl')
    
    # Check if cache exists and we're not forcing regeneration
    if os.path.exists(cache_path) and not force:
        try:
            with open(cache_path, 'rb') as f:
                emails = pickle.load(f)
                print(f"Found existing cache with {len(emails)} emails.")
                print(f"Use --force to regenerate all emails.")
                return True
        except Exception as e:
            print(f"Error reading cache: {str(e)}")
            # Continue to regenerate
    
    if force and os.path.exists(cache_path):
        print("Forcing regeneration of emails...")
        try:
            os.remove(cache_path)
            print("Removed existing cache file.")
        except Exception as e:
            print(f"Warning: Could not remove cache file: {str(e)}")
    
    print(f"Generating {count} emails using Gemini API...")
    print(f"Rate limit: {rate_limit} requests per minute")
    print(f"Batch size: {batch_size} emails")
    start_time = time.time()
    
    try:
        generator = GeminiEmailGenerator(requests_per_minute=rate_limit)
        emails = generator.generate_emails(count, batch_size=batch_size)
        end_time = time.time()
        
        print(f"Email generation completed in {end_time - start_time:.2f} seconds.")
        print(f"Generated {len(emails)} emails.")
        
        # Calculate average time per email
        if len(emails) > 0:
            avg_time = (end_time - start_time) / len(emails)
            print(f"Average time per email: {avg_time:.2f} seconds")
        
        # Count email types and priorities
        types = {}
        urgent_count = 0
        for email in emails:
            email_type = email.get('category', 'unknown')
            types[email_type] = types.get(email_type, 0) + 1
            if email.get('is_urgent', False):
                urgent_count += 1
        
        print("\nEmail Statistics:")
        print(f"- Total emails: {len(emails)}")
        print(f"- Urgent emails: {urgent_count} ({(urgent_count/len(emails))*100:.1f}%)")
        print("- Emails by type:")
        for email_type, count in types.items():
            print(f"  * {email_type}: {count} ({(count/len(emails))*100:.1f}%)")
        
        return True
    except Exception as e:
        print(f"Error generating emails: {str(e)}")
        return False

def show_help():
    """Show help message."""
    print("\nUsage: python generate_emails.py [options]")
    print("\nOptions:")
    print("  --force               Force regeneration of emails even if cache exists")
    print("  --count=<number>      Number of emails to generate (default: 200)")
    print("  --rate=<number>       Rate limit in requests per minute (default: 6)")
    print("  --batch=<number>      Batch size for processing (default: 10)")
    print("  --help                Show this help message")
    print("\nExamples:")
    print("  python generate_emails.py --count=50 --rate=3")
    print("  python generate_emails.py --force --batch=20")

if __name__ == "__main__":
    # Parse command line arguments
    force = "--force" in sys.argv
    count = 200  # Default
    rate_limit = 6  # Default
    batch_size = 10  # Default
    
    # Check for help flag
    if "--help" in sys.argv or "-h" in sys.argv:
        show_help()
        sys.exit(0)
    
    # Check for count parameter
    for arg in sys.argv:
        if arg.startswith("--count="):
            try:
                count = int(arg.split("=")[1])
                print(f"Will generate {count} emails.")
            except ValueError:
                print(f"Invalid count value: {arg}")
                sys.exit(1)
        elif arg.startswith("--rate="):
            try:
                rate_limit = int(arg.split("=")[1])
                if rate_limit < 1:
                    print("Rate limit must be at least 1 request per minute.")
                    rate_limit = 1
                elif rate_limit > 30:
                    print("WARNING: High rate limit may trigger API throttling.")
            except ValueError:
                print(f"Invalid rate limit value: {arg}")
                sys.exit(1)
        elif arg.startswith("--batch="):
            try:
                batch_size = int(arg.split("=")[1])
                if batch_size < 1:
                    print("Batch size must be at least 1.")
                    batch_size = 1
            except ValueError:
                print(f"Invalid batch size value: {arg}")
                sys.exit(1)
    
    print("=== CorporAI Email Generator ===")
    print("This utility generates synthetic corporate emails using the Gemini API.")
    
    # Check environment
    if not check_environment():
        print("\nEnvironment check failed. Please fix the issues and try again.")
        sys.exit(1)
    
    # Generate emails
    if generate_emails(count, force, rate_limit, batch_size):
        print("\nEmail generation completed successfully.")
        sys.exit(0)
    else:
        print("\nEmail generation failed.")
        sys.exit(1) 