# CorporAI - Smart Email Assistant

CorporAI is an LLM-powered email management tool designed for corporate professionals to better manage their inbox.

## Features

1. **Email Summarization**: Automatically summarizes emails while preserving important keywords and information.
2. **Priority Classification**: Classifies emails as high, medium, or low priority based on content analysis.
3. **High Priority Queue**: Maintains a running queue of the last 50 high priority emails.
4. **Executive Summary**: Generates a comprehensive summary of all high priority emails.
5. **Real Email Integration**: Can connect to real email accounts via IMAP (Gmail, Outlook, etc.)
6. **Gemini-Generated Emails**: Falls back to using Google's Gemini 2.0 Flash model to generate realistic corporate emails when real emails aren't available.

## Tech Stack

- **Backend**: Python with Flask
- **Frontend**: HTML, CSS, JavaScript
- **LLM API**: Google's Gemini 2.0 Flash model
- **Email Protocol**: IMAP for real email access

## Setup Instructions

### Prerequisites

- Python 3.8 or higher
- A Google AI API key with access to Gemini models
- (Optional) Email account credentials for using real emails

### Installation

1. Clone this repository:
```
git clone https://github.com/yourusername/corporai.git
cd corporai
```

2. Install the required packages:
```
pip install -r requirements.txt
```

3. Set up your environment variables:
   - Create a `.env` file in the root directory
   - Add your Gemini API key: `GEMINI_API_KEY=your_api_key_here`
   - (Optional) Add email credentials:
     ```
     EMAIL_ADDRESS=your-email@example.com
     EMAIL_PASSWORD=your-email-password
     IMAP_SERVER=imap.gmail.com
     IMAP_PORT=993
     ```

### Email Configuration

#### Using Real Emails (Recommended)

To use real emails, configure the following in your `.env` file:

```
EMAIL_ADDRESS=your-email@example.com
EMAIL_PASSWORD=your-email-password
IMAP_SERVER=your-imap-server
IMAP_PORT=993
```

Common IMAP servers:
- Gmail: `imap.gmail.com`
- Outlook/Office365: `outlook.office365.com`
- Yahoo Mail: `imap.mail.yahoo.com`
- AOL: `imap.aol.com`

**Note for Gmail users**: You may need to create an "App Password" instead of using your regular password. See [Google Account Help](https://support.google.com/accounts/answer/185833) for instructions.

#### Using Generated Emails (Fallback)

If email credentials are not provided, the application will fall back to generating mock emails using:
1. Gemini API (if API key is provided)
2. Random mock emails (if Gemini API is unavailable)

### Running the Application

1. Start the Flask application:
```
python run.py
```
   - On first run with email credentials, the app will attempt to connect to your email account
   - If email credentials are missing or invalid, it will generate emails using Gemini API
   - Generated emails are cached for subsequent runs

2. Open your browser and go to `http://localhost:5000`

### Command Line Options

The application supports the following command line options:

1. Generate emails only without starting the Flask app:
```
python run.py --gen-only
```

2. Force regeneration of emails (even if they exist in cache):
```
python run.py --regen
```

### Email Generation Utility

A dedicated utility is provided for more control over the email generation process:

```
python generate_emails.py [options]
```

Options:
- `--force`: Force regeneration of emails even if cache exists
- `--count=<number>`: Number of emails to generate (default: 200)
- `--rate=<number>`: Rate limit in requests per minute (default: 6)
- `--batch=<number>`: Batch size for generating emails (default: 10)
- `--help`: Show help message

Examples:
```
# Generate 50 emails with a conservative rate limit
python generate_emails.py --count=50 --rate=3

# Force regeneration with a larger batch size
python generate_emails.py --force --batch=20
```

## Usage

1. **Process an Email**:
   - Navigate to the "Process Email" tab
   - Enter the email subject and content
   - Click "Process Email" to get a summary and priority classification

2. **View High Priority Summary**:
   - Navigate to the "High Priority Summary" tab
   - Click "Get Summary" to view an executive summary of all high priority emails

## How It Works

1. **Email Retrieval/Generation**:
   - The app first tries to use real emails from your configured email account via IMAP
   - If that fails, it uses Gemini API to generate a set of realistic corporate emails
   - These emails are stored in a cache file (`app/models/generated_emails.pkl`) for future use
   - Rate limiting is implemented to avoid hitting API quotas

2. **Email Processing**:
   - Emails are processed using Gemini to extract summaries and determine priorities
   - High priority emails are tracked in a separate queue

## License

MIT License 