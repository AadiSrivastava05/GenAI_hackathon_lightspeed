import os
import sys
from dotenv import load_dotenv
import time
from app.app import app
from app.models.gemini_email_generator import GeminiEmailGenerator

# Load environment variables from .env file
load_dotenv()

def check_api_key():
    """Check if Gemini API key is set."""
    api_key = os.environ.get('GEMINI_API_KEY')
    if not api_key or api_key == 'your-api-key-here':
        print("WARNING: Gemini API key not set. Please set GEMINI_API_KEY in your environment or .env file.")
        print("You can get an API key from https://makersuite.google.com/app/apikey")
        return False
    return True

def check_email_credentials():
    """Check if real email credentials are configured."""
    email = os.environ.get('EMAIL_ADDRESS')
    password = os.environ.get('EMAIL_PASSWORD')
    imap_server = os.environ.get('IMAP_SERVER')
    
    if email and password and imap_server:
        print(f"Email credentials found for {email} using {imap_server}.")
        print("The application will attempt to use real emails instead of generated ones.")
        return True
    
    return False

def generate_emails(count=200, force=False, rate_limit=6):
    """Generate emails using Gemini API."""
    # Check if we have email credentials first
    if check_email_credentials() and not force:
        print("Real email credentials found. Skipping email generation.")
        print("The application will use your real emails instead.")
        print("Use --regen flag to force generation of mock emails anyway.")
        return True
        
    cache_file = os.path.join(os.path.dirname(__file__), 'app', 'models', 'generated_emails.pkl')
    
    if not os.path.exists(cache_file) or force:
        if force and os.path.exists(cache_file):
            print("Forcing regeneration of emails...")
            try:
                os.remove(cache_file)
                print("Removed existing cache file.")
            except Exception as e:
                print(f"Warning: Could not remove cache file: {str(e)}")
                
        print(f"Generating {count} emails using Gemini API (rate limit: {rate_limit} req/min)...")
        print("This may take a while. Progress will be saved incrementally.")
        try:
            start_time = time.time()
            generator = GeminiEmailGenerator(requests_per_minute=rate_limit)
            emails = generator.generate_emails(count, batch_size=10)
            end_time = time.time()
            
            print(f"Email generation completed in {end_time - start_time:.2f} seconds.")
            print(f"Generated {len(emails)} emails.")
            return True
        except Exception as e:
            print(f"Error generating emails: {str(e)}")
            print("Please check your Gemini API key and internet connection.")
            return False
    else:
        print(f"Email cache found at {cache_file}.")
        print("Use --regen flag to force regeneration.")
        return True

if __name__ == '__main__':
    # Check for command line flags
    force_regen = "--regen" in sys.argv
    gen_only_mode = "--gen-only" in sys.argv
    email_count = 200  # Default
    rate_limit = 6  # Default
    
    # Parse count and rate parameters
    for arg in sys.argv:
        if arg.startswith("--count="):
            try:
                email_count = int(arg.split("=")[1])
                print(f"Will generate {email_count} emails.")
            except ValueError:
                print(f"Invalid count value: {arg}, using default of 200.")
        elif arg.startswith("--rate="):
            try:
                rate_limit = int(arg.split("=")[1])
                if rate_limit < 1:
                    print("Rate limit must be at least 1 request per minute.")
                    rate_limit = 1
                elif rate_limit > 30:
                    print("WARNING: High rate limit may trigger API throttling.")
            except ValueError:
                print(f"Invalid rate limit value: {arg}, using default of 6.")
    
    # Give more precedence to real emails
    if not force_regen and check_email_credentials():
        print("Real email credentials detected!")
        print("The application will use real emails instead of generated ones.")
        print("Use --regen flag to force generation of mock emails.")
    # Check API key only if we actually need it
    elif not check_api_key():
        exit(1)
    
    # Handle generation-only mode
    if gen_only_mode:
        # Only generate emails, don't run the Flask app
        success = generate_emails(email_count, force_regen, rate_limit)
        exit(0 if success else 1)
    
    # Normal operation - generate emails (if needed) and run app
    if not generate_emails(email_count, force_regen, rate_limit):
        exit(1)
    
    # Run the Flask app
    print("\nStarting Flask application...")
    app.run(debug=True) 