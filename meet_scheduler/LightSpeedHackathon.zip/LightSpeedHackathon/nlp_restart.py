import os
import json
import uuid
import re
import datetime
import dateparser
import google.generativeai as genai
from flask import Flask, render_template, request, jsonify, redirect, url_for
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

app = Flask(__name__)

# Configuration
CREDENTIALS_FILE = 'credentials.json'
TOKEN_FILE = 'token.json'
SCOPES = ['https://www.googleapis.com/auth/calendar']

# Mock company database for email mapping
COMPANY_DATABASE = {
    'rathneesh': 'me23b055@smail.iitm.ac.in',
    'aditya': 'cs23b003@smail.iitm.ac.in',
    # Add more people as needed
}

# Initialize Gemini API
def initialize_gemini():
    try:
        # Load API key from environment variable
        api_key = 'AIzaSyDUlTStDsBLgmdsXnvhjsfWC3KShr-cogY'
        if not api_key:
            print("Warning: GEMINI_API_KEY not found in environment variables. Please set it.")
            return None
        
        genai.configure(api_key=api_key)
        return genai.GenerativeModel('gemini-2.0-flash')
    except Exception as e:
        print(f"Error initializing Gemini API: {e}")
        return None

# Get Google Calendar credentials
def get_calendar_credentials():
    creds = None
    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_info(json.load(open(TOKEN_FILE)))
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        
        with open(TOKEN_FILE, 'w') as token:
            token.write(creds.to_json())
    
    return creds

# Map names to email addresses from company database
def map_names_to_emails(names):
    emails = []
    unmapped_names = []
    
    for name in names:
        # Clean the name (remove punctuation, convert to lowercase)
        clean_name = re.sub(r'[^\w\s]', '', name.lower()).strip()
        
        # Check if name exists in database
        if clean_name in COMPANY_DATABASE:
            emails.append(COMPANY_DATABASE[clean_name])
        else:
            # Check if it's already an email
            if re.match(r'^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}$', name):
                emails.append(name)
            else:
                unmapped_names.append(name)
                # Keep the original name as is if not found
                emails.append(name)
    
    return emails, unmapped_names

# Parse natural language to meeting details using Gemini
def parse_meeting_details(model, query):
    if not model:
        return None
    
    prompt = f"""
    Parse the following meeting request and extract the following information:
    1. Attendees (email addresses or names of people)
    2. Meeting date and time
    3. Duration (in minutes)
    4. Meeting title/subject
    5. Any additional notes
    
    Request: {query}
    
    Format your response as a JSON object with the following keys:
    {{
        "attendees": [list of attendees],
        "datetime": "YYYY-MM-DD HH:MM",
        "duration": duration in minutes (integer),
        "title": "meeting title",
        "notes": "any additional notes"
    }}
    """
    
    try:
        response = model.generate_content(prompt)
        response_text = response.text
        
        # Extract JSON from response
        start_idx = response_text.find('{')
        end_idx = response_text.rfind('}')
        
        if start_idx != -1 and end_idx != -1:
            json_str = response_text[start_idx:end_idx+1]
            meeting_details = json.loads(json_str)
            
            # Map names to email addresses
            if 'attendees' in meeting_details:
                emails, unmapped_names = map_names_to_emails(meeting_details['attendees'])
                meeting_details['attendees'] = emails
                meeting_details['unmapped_names'] = unmapped_names
            
            return meeting_details
        else:
            return None
    except Exception as e:
        print(f"Error parsing meeting details: {e}")
        return None

# Create Google Calendar event with Google Meet link
def create_calendar_event(meeting_details):
    try:
        creds = get_calendar_credentials()
        service = build('calendar', 'v3', credentials=creds)
        
        # Parse datetime
        start_time = dateparser.parse(meeting_details['datetime'])
        duration = int(meeting_details['duration'])
        end_time = start_time + datetime.timedelta(minutes=duration)
        
        # Format attendees
        attendees = [{'email': attendee} for attendee in meeting_details['attendees']]
        
        # Create event with conference data
        event = {
            'summary': meeting_details['title'],
            'description': meeting_details['notes'],
            'start': {
                'dateTime': start_time.isoformat(),
                'timeZone': 'UTC',
            },
            'end': {
                'dateTime': end_time.isoformat(),
                'timeZone': 'UTC',
            },
            'attendees': attendees,
            'conferenceData': {
                'createRequest': {
                    'requestId': str(uuid.uuid4()),
                    'conferenceSolutionKey': {
                        'type': 'hangoutsMeet'
                    }
                }
            }
        }
        
        # Insert the event with conferenceDataVersion=1
        event = service.events().insert(
            calendarId='primary',
            body=event,
            conferenceDataVersion=1
        ).execute()
        
        return {
            'event_id': event['id'],
            'meet_link': event.get('conferenceData', {}).get('entryPoints', [{}])[0].get('uri', 'No meet link available')
        }
    except Exception as e:
        print(f"Error creating calendar event: {e}")
        return None

# Flask routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/schedule', methods=['POST'])
def schedule_meeting():
    query = request.form.get('query')
    if not query:
        return jsonify({'error': 'No query provided'}), 400
    
    model = initialize_gemini()
    if not model:
        return jsonify({'error': 'Failed to initialize Gemini API'}), 500
    
    meeting_details = parse_meeting_details(model, query)
    if not meeting_details:
        return jsonify({'error': 'Failed to parse meeting details'}), 400
    
    result = create_calendar_event(meeting_details)
    if not result:
        return jsonify({'error': 'Failed to create calendar event'}), 500
    
    # Prepare response with additional information about mapped names
    response_data = {
        'success': True,
        'meeting_details': meeting_details,
        'meet_link': result['meet_link']
    }
    
    # Add information about unmapped names if any
    if 'unmapped_names' in meeting_details and meeting_details['unmapped_names']:
        response_data['unmapped_names'] = meeting_details['unmapped_names']
        response_data['warning'] = 'Some names could not be found in the company database.'
    
    return jsonify(response_data)

# Create templates directory and HTML file
os.makedirs('templates', exist_ok=True)

with open('templates/index.html', 'w') as f:
    f.write('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NLP Meeting Scheduler</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f5f7fa;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 2rem;
        }
        header {
            text-align: center;
            margin-bottom: 2rem;
        }
        h1 {
            color: #1a73e8;
            margin-bottom: 0.5rem;
        }
        .subtitle {
            color: #5f6368;
            font-size: 1.1rem;
        }
        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #dadce0;
            border-radius: 4px;
            font-size: 1rem;
            font-family: inherit;
            resize: vertical;
            min-height: 100px;
        }
        button {
            background-color: #1a73e8;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        button:hover {
            background-color: #1557b0;
        }
        .result {
            display: none;
            margin-top: 2rem;
        }
        .result h2 {
            color: #1a73e8;
            margin-bottom: 1rem;
        }
        .meet-link {
            display: block;
            margin-top: 1rem;
            padding: 1rem;
            background-color: #e8f0fe;
            border-radius: 4px;
            color: #1a73e8;
            text-decoration: none;
            font-weight: 500;
            text-align: center;
        }
        .meet-link:hover {
            background-color: #d2e3fc;
        }
        .details {
            margin-top: 1.5rem;
        }
        .details h3 {
            margin-bottom: 0.5rem;
            color: #5f6368;
        }
        .details ul {
            list-style-type: none;
            padding: 0;
        }
        .details li {
            padding: 0.5rem 0;
            border-bottom: 1px solid #f1f3f4;
        }
        .details li:last-child {
            border-bottom: none;
        }
        .loading {
            display: none;
            text-align: center;
            margin-top: 1rem;
        }
        .loading-spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #1a73e8;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .error {
            display: none;
            color: #d93025;
            background-color: #fce8e6;
            padding: 1rem;
            border-radius: 4px;
            margin-top: 1rem;
        }
        .examples {
            margin-top: 2rem;
            color: #5f6368;
        }
        .examples h3 {
            margin-bottom: 0.5rem;
        }
        .examples p {
            margin-bottom: 0.25rem;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>NLP Meeting Scheduler</h1>
            <p class="subtitle">Describe your meeting in natural language and we'll schedule it with Google Meet</p>
        </header>
        
        <div class="card">
            <form id="scheduler-form">
                <div class="form-group">
                    <label for="query">Describe your meeting:</label>
                    <textarea id="query" name="query" placeholder="Example: Schedule a team meeting with john@example.com and sarah@example.com tomorrow at 2pm for 45 minutes to discuss the project roadmap."></textarea>
                </div>
                <button type="submit">Schedule Meeting</button>
            </form>
            
            <div class="loading">
                <div class="loading-spinner"></div>
                <p>Processing your request...</p>
            </div>
            
            <div class="error" id="error-message"></div>
        </div>
        
        <div class="result" id="result">
            <h2>Meeting Scheduled!</h2>
            <a href="#" class="meet-link" id="meet-link" target="_blank">Join Google Meet</a>
            
            <div class="details">
                <h3>Meeting Details:</h3>
                <ul id="meeting-details">
                    <!-- Details will be inserted here -->
                </ul>
            </div>
        </div>
        
        <div class="examples card">
            <h3>Example Queries:</h3>
            <p>"Schedule a project kickoff with the team (team@example.com) next Monday at 10am for 1 hour"</p>
            <p>"Set up a quick 30-minute sync with Alex (alex@example.com) tomorrow afternoon"</p>
            <p>"Create a weekly team meeting every Friday at 3pm with the engineering team for sprint planning"</p>
        </div>
    </div>
    
    <script>
        document.getElementById('scheduler-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const query = document.getElementById('query').value.trim();
            if (!query) return;
            
            // Show loading, hide previous results/errors
            document.querySelector('.loading').style.display = 'block';
            document.getElementById('result').style.display = 'none';
            document.getElementById('error-message').style.display = 'none';
            
            // Send request to server
            fetch('/schedule', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    'query': query
                })
            })
            .then(response => response.json())
            .then(data => {
                // Hide loading
                document.querySelector('.loading').style.display = 'none';
                
                if (data.error) {
                    // Show error
                    const errorElement = document.getElementById('error-message');
                    errorElement.textContent = data.error;
                    errorElement.style.display = 'block';
                    return;
                }
                
                // Show result
                document.getElementById('result').style.display = 'block';
                
                // Update meet link
                const meetLinkElement = document.getElementById('meet-link');
                meetLinkElement.href = data.meet_link;
                meetLinkElement.textContent = 'Join Google Meet: ' + data.meet_link;
                
                // Update meeting details
                const detailsList = document.getElementById('meeting-details');
                detailsList.innerHTML = '';
                
                const details = data.meeting_details;
                
                // Add title
                const titleItem = document.createElement('li');
                titleItem.textContent = `Title: ${details.title}`;
                detailsList.appendChild(titleItem);
                
                // Add date/time
                const dateItem = document.createElement('li');
                dateItem.textContent = `When: ${details.datetime}`;
                detailsList.appendChild(dateItem);
                
                // Add duration
                const durationItem = document.createElement('li');
                durationItem.textContent = `Duration: ${details.duration} minutes`;
                detailsList.appendChild(durationItem);
                
                // Add attendees
                const attendeesItem = document.createElement('li');
                attendeesItem.textContent = `Attendees: ${details.attendees.join(', ')}`;
                detailsList.appendChild(attendeesItem);
                
                // Add notes if available
                if (details.notes) {
                    const notesItem = document.createElement('li');
                    notesItem.textContent = `Notes: ${details.notes}`;
                    detailsList.appendChild(notesItem);
                }
                
                // Add warning about unmapped names if any
                if (data.warning) {
                    const warningItem = document.createElement('li');
                    warningItem.style.color = '#d93025';
                    warningItem.textContent = data.warning;
                    detailsList.appendChild(warningItem);
                }
            })
            .catch(error => {
                // Hide loading
                document.querySelector('.loading').style.display = 'none';
                
                // Show error
                const errorElement = document.getElementById('error-message');
                errorElement.textContent = 'An error occurred. Please try again.';
                errorElement.style.display = 'block';
                console.error('Error:', error);
            });
        });
    </script>
</body>
</html>
''')

# Create .env file for API key
with open('.env', 'w') as f:
    f.write('GEMINI_API_KEY=your_gemini_api_key_here\n')

if __name__ == '__main__':
    app.run(debug=True)
